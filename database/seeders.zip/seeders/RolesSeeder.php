<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $superRole = Role::firstOrCreate(['name' => 'Super']);

         // Asignar todos los permisos al rol Super
         $permissions = Permission::all();
         $superRole->syncPermissions($permissions);
    }
}
