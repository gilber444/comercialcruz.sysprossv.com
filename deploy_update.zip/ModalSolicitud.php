<?php

namespace App\Http\Livewire;

use App\Models\Inventarios;
use App\Models\Productos;
use App\Models\Sucursales;
use App\Models\VentasResumen;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class ModalSolicitud extends Component
{
    public $search, $products = [], $sucursales, $detalleExistencias = [], $productoSeleccionado, $ultimoProductoCargado = null;

    public function mount()
    {
        $this->sucursales = Sucursales::all();
    }

    public function liveSearch()
    {
        $user = Auth::user();

        if (strlen($this->search) > 0) {
            $this->reset('products');

            $productosActivos = DB::table('productos')
             ->where('activo', 1) // ← línea original
            ->whereNull('deleted_at'); // ← NUEVO: agregada aquí para excluir productos eliminados
          //  ->where('activo', 1);
            $this->products = DB::table(DB::raw("({$productosActivos->toSql()}) as p"))
                ->mergeBindings($productosActivos)
                ->join('medidas as m', 'm.id', '=', 'p.medida')
                ->join('precios as pr', function ($join) {
                    $join->on('pr.producto', '=', 'p.id')->whereNull('pr.deleted_at');
                })
                ->join('inventarios as i', function ($join) use ($user) {
                    $join->on('i.producto', '=', 'p.id')->where('i.sucursal', '=', $user->sucursal);
                })
                ->select(
                    'p.id',
                    'p.nombreProducto',
                    'p.codebar3',
                    'm.unidad as presentacion',
                    'pr.cantidad',
                    'pr.costosiva',
                    'i.existencia'
                )
                 ->where('p.activo', 1)          // ← NUEVO: aseguramos productos activos
                 ->whereNull('p.deleted_at')     // ← NUEVO: aseguramos que no estén eliminados
                //->where('p.activo', '=', 1) // ← importante: mantenelo aquí
                ->where(function ($q) {
                    $q->where('p.nombreProducto', 'like', "%{$this->search}%")
                        ->orWhere('p.codebar1', 'like', "%{$this->search}%")
                        ->orWhere('p.codebar2', 'like', "%{$this->search}%")
                        ->orWhere('p.codebar3', 'like', "%{$this->search}%")
                        ->orWhere('p.codealternativo', 'like', "%{$this->search}%");
                })
                ->groupBy(
                    'p.id',
                    'p.nombreProducto',
                    'p.codebar3',
                    'm.unidad',
                    'pr.cantidad',
                    'pr.costosiva',
                    'i.existencia'
                )
                ->orderBy('p.nombreProducto', 'asc')
                ->take(100) 
                ->get();
        } else {
            $this->products = [];
        }
    }

    public function calcularDetalleExistencias($productId)
    {
        $idsSucursales = $this->sucursales->pluck('id');

        $datos = DB::table('inventarios as i')
            ->leftJoin('ventas_resumen as v', function($q) use($productId) {
                $q->on('i.producto', '=', 'v.producto')
                ->on('i.sucursal', '=', 'v.sucursal')
                ->where('v.producto', '=', $productId);
            })
            ->where('i.producto', $productId)
            ->whereIn('i.sucursal', $idsSucursales)
            ->select(
                'i.sucursal',
                'i.existencia',
                DB::raw('COALESCE(v.cantidad_30,0) as ventas30'),
                DB::raw('COALESCE(v.cantidad_90,0) as ventas90')
            )
            ->get();

        $detalle = [];

        foreach ($datos as $d) {
            $color = match (true) {
                $d->ventas30 == 0 && $d->existencia == 0 => '#d1d1cf',
                $d->existencia == 0 && $d->ventas90 > 0 => '#46ed2f',
                $d->existencia >= $d->ventas30 => '#ffffff',
                $d->existencia < $d->ventas30 => '#ffff00',
                $d->existencia > $d->ventas90 * 3 => '#e44141',
                default => '#ffffff',
            };

            $detalle[$d->sucursal] = [
                'existencia' => $d->existencia,
                'ventas30' => $d->ventas30,
                'ventas90' => $d->ventas90,
                'color' => $color,
            ];
        }

        return $detalle;
    }

    protected $listeners = ['loadExistencias' => 'loadExistencias'];


    public function Add($id)
    {
        $this->emit('scan-code-byid', $id);
    }

    public function render()
    {
        return view('livewire.existencias.modal-solicitud');
    }
}
