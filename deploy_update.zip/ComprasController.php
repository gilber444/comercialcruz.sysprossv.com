<?php

namespace App\Http\Livewire;

use App\Models\Compras;
use App\Models\ComprasDetalles;
use App\Models\CuentasPagar;
use App\Models\Inventarios;
use App\Models\Kardex;
use App\Models\Pagos;
use App\Models\Sucursales;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Livewire\Component;
use Livewire\WithPagination;

class ComprasController extends Component
{
    use WithPagination;

    public $search, $selected_id, $pageTitle, $componentName, $detalleCompras = [];
    public $filterEstado = '', $filterCondiPago = '', $fechaDesde, $fechaHasta, $perPage = 20, $filterSucursal = 0;
    public $debugCompras = [];

    private $pagination = 20;

    public function mount()
    {
        $this->pageTitle = 'Listado';
        $this->componentName = 'Compras';
        $this->fechaDesde = now()->toDateString();
        $this->fechaHasta = now()->toDateString();
        $this->filterSucursal = Auth::user()->can('Compras_ViewAll') ? 0 : (Auth::user()->sucursal ?? 0);
    }

    public function updatingSearch() { $this->resetPage(); }
    public function updatingFilterEstado() { $this->resetPage(); }
    public function updatingFilterCondiPago() { $this->resetPage(); }
    public function updatingFechaDesde() { $this->resetPage(); }
    public function updatingFechaHasta() { $this->resetPage(); }
    public function updatingPerPage() { $this->resetPage(); }
    public function updatingFilterSucursal() { $this->resetPage(); }

    public function limpiarFiltros()
    {
        $this->search = '';
        $this->filterEstado = '';
        $this->filterCondiPago = '';
        $this->filterSucursal = Auth::user()->can('Compras_ViewAll') ? 0 : (Auth::user()->sucursal ?? 0);
        $this->fechaDesde = now()->startOfMonth()->toDateString();
        $this->fechaHasta = now()->endOfMonth()->toDateString();
        $this->perPage = 20;
        $this->resetPage();
    }

    public function setRango(string $rango)
    {
        switch ($rango) {
            case 'hoy':
                $this->fechaDesde = now()->toDateString();
                $this->fechaHasta = now()->toDateString();
                break;
            case 'semana':
                $this->fechaDesde = now()->startOfWeek()->toDateString();
                $this->fechaHasta = now()->endOfWeek()->toDateString();
                break;
            case 'mes':
                $this->fechaDesde = now()->startOfMonth()->toDateString();
                $this->fechaHasta = now()->endOfMonth()->toDateString();
                break;
            case 'anio':
                $this->fechaDesde = now()->startOfYear()->toDateString();
                $this->fechaHasta = now()->endOfYear()->toDateString();
                break;
            case 'todo':
                $this->fechaDesde = '';
                $this->fechaHasta = '';
                break;
        }

        $this->resetPage();
    }

    public function paginationView()
    {
        return 'vendor.livewire.bootstrap';
    }

    public function render()
    {
        $user = Auth::user();

        $query = Compras::query()
            ->with([
                'Rproveedores:id,nombre',
                'RtipoCompra:id,tipo',
                'Rsucursal:id,nombre',
                'Rusers:id,name'
            ])
            ->select('compras.*')
            ->selectSub(function ($q) {
                $q->from('compras_detalles')
                    ->selectRaw('COALESCE(SUM(cantidad), 0)')
                    ->where(function ($sub) {
                        $sub->whereColumn('compras_detalles.compra', 'compras.id');
                        $sub->orWhere(function ($nested) {
                            $nested->whereNotNull('compras.id_vps')
                                ->whereColumn('compras_detalles.compra', 'compras.id_vps');
                        });
                    });
            }, 'total_productos');

        $debug = [
            'base' => (clone $query)->count(),
        ];

        if ($this->fechaDesde && $this->fechaHasta) {
            $query->whereDate('compras.fecha', '>=', $this->fechaDesde)
                ->whereDate('compras.fecha', '<=', $this->fechaHasta);
        } elseif ($this->fechaDesde) {
            $query->whereDate('compras.fecha', '>=', $this->fechaDesde);
        } elseif ($this->fechaHasta) {
            $query->whereDate('compras.fecha', '<=', $this->fechaHasta);
        }

        $debug['fecha'] = (clone $query)->count();

        if ($this->filterEstado) {
            $query->where('compras.estado', $this->filterEstado);
        }

        $debug['estado'] = (clone $query)->count();

        if ($this->filterCondiPago) {
            $query->where('compras.condi_pago', $this->filterCondiPago);
        }

        $debug['condicion'] = (clone $query)->count();

        if (!empty($this->search)) {
            $search = trim($this->search);
            $query->where(function ($q) use ($search) {
                $q->whereHas('Rproveedores', fn ($proveedor) => $proveedor->where('nombre', 'like', "%$search%"))
                    ->orWhereHas('RtipoCompra', fn ($tipo) => $tipo->where('tipo', 'like', "%$search%"))
                    ->orWhereHas('Rsucursal', fn ($sucursal) => $sucursal->where('nombre', 'like', "%$search%"))
                    ->orWhereHas('Rusers', fn ($usuario) => $usuario->where('name', 'like', "%$search%"))
                    ->orWhere('compras.fecha', 'like', "%$search%")
                    ->orWhere('compras.total', 'like', "%$search%")
                    ->orWhere('compras.estado', 'like', "%$search%")
                    ->orWhere('compras.condi_pago', 'like', "%$search%")
                    ->orWhere('compras.correlativo', 'like', "%$search%")
                    ->orWhere('compras.generacion', 'like', "%$search%");
            });
        }

        $debug['busqueda'] = (clone $query)->count();

        if ((int) $this->filterSucursal > 0) {
            $query->where('compras.sucursal', (int) $this->filterSucursal);
        } elseif (!$user->can('Compras_ViewAll') && !empty($user->sucursal)) {
            $query->where('compras.sucursal', $user->sucursal);
        }

        $debug['sucursal'] = (clone $query)->count();
        $debug['user_sucursal'] = $user->sucursal ?? null;
        $debug['view_all'] = $user->can('Compras_ViewAll') ? 'si' : 'no';
        $debug['filtro_sucursal'] = $this->filterSucursal;
        $this->debugCompras = $debug;

        $estados = Compras::query()
            ->select('estado')
            ->distinct()
            ->orderBy('estado')
            ->pluck('estado')
            ->filter();

        $condiciones = collect(['Credito', 'Contado']);
        $sucursales = Sucursales::orderBy('nombre')->get(['id', 'nombre']);
        $totalRegistros = $query->count();
        $data = $query->orderByDesc('compras.fecha')->paginate($this->perPage);

        return view('livewire.compras.compras', ['compras' => $data, 'estados' => $estados, 'condiciones' => $condiciones, 'sucursales' => $sucursales, 'totalRegistros' => $totalRegistros])
            ->extends('layouts.theme.app')
            ->section('content');
    }

    protected $listeners = [
        'deleteRow' => 'Destroy',
        'anulaRow' => 'anular'
    ];

    public function Destroy(Compras $compra)
    {
        $compra->delete();
        $this->emit('item-deleted', 'Producto Eliminado');
    }

    public function cargarDetallesCompra($compraId)
    {
        $compra = Compras::findOrFail($compraId);

        $parentKeys = array_values(array_unique(array_filter([
            $compra->id,
            $compra->id_vps ?? null,
        ])));

        $this->detalleCompras = ComprasDetalles::from('compras_detalles as cd')
            ->join('productos as p', 'p.id', 'cd.producto')
            ->join('medidas as m', 'm.id', 'cd.medida')
            ->select(
                'cd.id',
                'cd.cantidad',
                'cd.costo',
                'cd.total',
                'p.nombreProducto as producto',
                'm.unidad as medida'
            )
            ->whereIn('cd.compra', $parentKeys)
            ->get()
            ->map(function ($row) use ($compra) {
                $row->estado_compras = $compra->estado;
                return $row;
            });

        $this->emit('detalle-modal', 'show modal');
    }

    public function anular($id)
    {
        $compra = Compras::find($id);

        if (\App\Helpers\SistemaHelper::operacionBloqueada((int) $compra->sucursal)) {
            $this->emit('noti', 'Bloqueado', 'Esta sucursal opera en modo local. Anula la compra desde la PC local.', 'error');
            return;
        }

        $detalle = ComprasDetalles::where('compra', $compra->id)->get();

        foreach ($detalle as $det) {
            $inventario = Inventarios::where('producto', $det->producto)->where('sucursal', $compra->sucursal)->first();

            $newExist = $inventario->existencia - $det->ingreso;

            $inventario->existencia = $newExist;
            $inventario->save();

            $ultiR = Kardex::where('producto', $det->producto)->where('inventario', $inventario->id)->latest()->first();

            $saldoCantidad = $newExist;
            $saldoValor = $ultiR->saldoValor + ($det->costo * $det->ingreso);
            Kardex::create([
                'producto' => $det->producto,
                'inventario' => $inventario->id,
                'descripcion' => 'Anulacion de la compra ' . $compra->correlativo,
                'fecha' => date('Y-m-d'),
                'hora' => date('H:i:s'),
                'ingresoCantidad' => 0.00,
                'ingresoValor' => 0.00,
                'egresoCantidad' => $det->cantidad,
                'egresoValor' => $det->costo * $det->cantidad,
                'saldoCantidad' => $saldoCantidad,
                'saldoValor' => $saldoValor,
            ]);
        }

        $cuentasIds = CuentasPagar::where('compra', $compra->id)->pluck('id');
        Pagos::whereIn('cuenta_pagar', $cuentasIds)->delete();
        CuentasPagar::where('compra', $compra->id)->delete();
        $compra->estado = 'Anulado';
        $compra->save();

        $compra->estado = 'Anulado';
        $compra->save();

        $this->emit('item-updated', 'Compra Anulada');
    }
}
