<div class="row">
    <div class="col-sm-12  col-md-12 mb-2">
        <label for="">Proveedor o Empresa</label>
        <style>
            .input__aumentar_width{
                box-shadow: none !important;
            }
            .input__aumentar_width .position-relative{
                width: 30rem !important;
            }
        </style>
        <div class="input-group input__aumentar_width" wire:ignore>
            <select class="form-select select2 w-50" id="proveedorCompra" style="width: 100%" >
                <option selected="">Elegir un Proveedor para esta factura... </option>
                @foreach ($proveedores as $proveedor)
                    <option value="{{ $proveedor->id }}">{{$proveedor->nombre }}</option>
                @endforeach
            </select>

            @can('Proveedor_Compra')
                <a href="javascript:void(0)" class="btn btn-primary btn-rounded mb-2" data-bs-toggle="modal" data-bs-target="#ProveedorCompra"> <i class="fa-solid fa-plus"></i></a>
            @endcan
        </div>
        <span>{{ $proveedorSelectName }}</span>
        @error('proveedorCompras') <span class="text-danger er">{{ $message}}</span>@enderror
        @error('proveedorSelectId') <span class="text-danger er">{{ $message}}</span>@enderror
    </div>
    <div class="col-sm-12 col-md-3 mb-2">
        <label for="">Tipo de Factura</label>
        <div class="input-group">
            <select class="form-select" id="tipo_factura" wire:model='factura' wire:change='calcularPercepcion'>
                <option selected="">Elegir...</option>
                @foreach ($tipos as $tipo)
                    <option value="{{ $tipo->id }}">{{$tipo->tipo }}</option>
                @endforeach
            </select>
        </div>
        @error('factura') <span class="text-danger er">{{ $message}}</span>@enderror
    </div>
    @if($factura && \App\Models\tipoCompras::find($factura) && str_contains(strtolower(\App\Models\tipoCompras::find($factura)->tipo ?? ''), 'nota'))
    <div class="col-12 mb-2">
        <div class="alert alert-warning py-2 mb-0 d-flex align-items-center gap-2">
            <i class="fa-solid fa-triangle-exclamation"></i>
            <span><strong>Nota de Crédito:</strong> El inventario se <strong>restará</strong> en lugar de sumarse. Se aplicará como crédito contra deuda pendiente del proveedor.</span>
        </div>
    </div>
    @endif
    {{-- @if ($factura == 4)
        <div class="col-sm-12 col-md-4 mb-2">
            <label for="">Elegir Credito Fiscal</label>
            <div class="input-group">
                <select class="form-select" id="fiscal" wire:model='fiscal'>
                    <option selected="">Elegir Credito Fiscal...</option>
                    @foreach ($creditosFiscales as $c)
                        <option value="{{ $c->id }}">
                            {{ $c->Rclientes->nombreCliente }} -- Numero: {{$c->numero }} -- Fecha: {{$c->fecha }} -- $ {{ number_format($c->total, 2)}}
                        </option>
                    @endforeach
                </select>
            </div>
            @error('fiscal') <span class="text-danger er">{{ $message}}</span>@enderror
        </div>
    @endif --}}

    {{-- <div class="col-sm-12  {{ $factura == 4 ? 'col-md-2' : 'col-md-4' }} mb-2"> --}}
    <div class="col-sm-12 col-md-3 mb-2">
        <label for="">Numero de Control</label>
        <div class="input-group">
            <span class="input-group-text" id="basic-addon11"><i class="fa-solid fa-hashtag"></i></span>
            <input type="text" wire:model.lazy='correlativo' class="form-control">
        </div>
        @error('correlativo') <span class="text-danger er"> {{$message}}</span>@enderror
    </div>
    {{-- <div class="col-sm-12 {{ $factura == 4 ? 'col-md-2' : 'col-md-4' }} mb-2"> --}}
    <div class="col-sm-12 col-md-3 mb-2">
        <label for="">Sello</label>
        <div class="input-group">
            <span class="input-group-text">
                <i class="fa-solid fa-hashtag"></i>
            </span>
            <input type="text" class="form-control" wire:model.lazy='serie'>
        </div>
        @error('serie')
            <span class="text-danger">{{ $message }}</span>
        @enderror
    </div>
    {{-- <div class="col-sm-12  {{ $factura == 4 ? 'col-md-2' : 'col-md-4' }} mb-2"> --}}
    <div class="col-sm-12 col-md-3 mb-2">
        <label for="">N° de Generacion</label>
        <div class="input-group">
            <span class="input-group-text" id="basic-addon11"><i class="fa-solid fa-hashtag"></i></span>
            <input type="text" wire:model.lazy='generacion' class="form-control">
        </div>
        @error('generacion') <span class="text-danger er"> {{$message}}</span>@enderror
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-3 mb-2">
        <label for="">Fecha</label>
        <div class="input-group">
            <input readonly id="fechaInput" type="date" class="form-control" placeholder="0000" wire:model='fecha'>
        </div>
        @error('fecha') <span class="text-danger er">{{ $message}}</span>@enderror
    </div>
    <div class="col-sm-12 col-md-3 mb-2">
        <label for="">Condicion de Pago</label>
        <div class="input-group">
            <select class="form-control" wire:model.lazy='condiPago'>
                <option value="Elegir">Elegir</option>
                <option value="Credito">Credito</option>
                <option value="Contado">Contado</option>
            </select>
        </div>
        @error('condiPago') <span class="text-danger er">{{ $message}}</span>@enderror
    </div>
    <div class="col-sm-12 col-md-3 mb-2">
        <label for="">Nombre del Vendedor</label>
        <div class="input-group">
            <input id="vendedor" type="text" class="form-control" placeholder="Nombre del vendedor" wire:model='vendedor'>
        </div>
        @error('vendedor') <span class="text-danger er">{{ $message}}</span>@enderror
    </div>
    <div class="col-sm-12 col-md-3 mb-2">
        <label for="">Ubicacion de la Compra</label>
        <div class="input-group" style="width: 100%">
            <select class="form-control" wire:model='sucursal' style="width: 100%">
                <option value="">Elegir</option>
                @foreach ($sucursales as  $s)
                    <option value="{{ $s->id }}">{{ $s->Rempresa->empresa }} - {{ $s->nombre }}</option>
                @endforeach
            </select>
        </div>
        @error('sucursal') <span class="text-danger er">{{ $message}}</span>@enderror
    </div>
</div>


@push('scripts')
<script>
    document.addEventListener('livewire:load', function () {
        let tipoSelect = $('#tipo_factura');
        tipoSelect.select2();

        tipoSelect.on('change', function () {
            var tipoId = $(this).val();
            @this.set('factura', tipoId);
            @this.call('calcularPorTipoFactura');
        });

        Livewire.hook('message.processed', () => {
            tipoSelect.select2();
        });
    });
</script>
@endpush
