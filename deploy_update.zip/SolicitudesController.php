<?php

namespace App\Http\Livewire;

use App\Models\Inventarios;
use App\Models\Kardex;
use App\Models\Precios;
use App\Models\Productos;
use App\Models\Solicitudes;
use App\Models\SolicitudesDetalles;
use App\Models\Sucursales;
use App\Models\tmpSolicitudes;
use App\Models\VentasDetalles;
use App\Models\VentasResumen;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Str;
use Livewire\Component;
use Livewire\WithPagination;
use Illuminate\Support\Facades\Cache;

class SolicitudesController extends Component
{
    use WithPagination;

    public $origen,
        $origen1,
        $destino,
        $destino1,
        $search,
        $selected_id,
        $correlativo,
        $fecha,
        $detalle,
        $itemsQuantity,
        $total,
        $can = [],
        $empre,
        $sucu,
        $ca,
        $rol,
        $cart = [],
        $uni = [],
        $modalItemId,
        $modalCantidad,
        $productoSeleccionado = null,
        $precioMostrarInfo = null,
        $sucursales,
        $existencias = [],
        $products = [],
        $nombreProductoSeleccionado,
        $cargaVentasRendered,
        $detalleExistencias = [];
    private $pagination = 7;

    public function mount()
    {
        $this->productoSeleccionado = null;
        $this->origen = session('origen', null);
        $this->destino = session('destino', null);
        $this->detalle = session('detalle', null);
        $user = Auth::user();
        $this->rol = $user->profile;
        $bus = Solicitudes::orderBy('id', 'desc')->first();

        $this->fecha = date('Y-m-d H:i:s');

        if ($bus) {
            $this->correlativo = $bus->numero + 1;
        } else {
            // Si no se encontraron registros, puedes asignar un valor predeterminado
            $this->correlativo = 1;
        }
        $user = Auth::user();

        if ($user->profile === 'Super' || $user->profile === 'Administrador' || $user->profile === 'Auditor') {
            $this->origen1 = Sucursales::with('Rempresa')->orderBy('nombre')->get();
            $this->destino1 = Sucursales::with('Rempresa')->OrderBy('nombre')->get();
        } else {
            $this->origen1 = Sucursales::with('Rempresa')->find($user->sucursal);
            $this->destino1 = Sucursales::with('Rempresa')->OrderBy('nombre')->get();
            //$this->destino = $this->destino1->id;
            $this->origen = $this->origen1->id;
        }

        $this->empre = $user->empresa;
        $this->sucu = $user->sucursal;
        $this->sucursales = Sucursales::all();
        $this->sucursales2 = Sucursales::whereNotIn('id', [11, 12, 14])->get();
        $this->Carrito();
    }

    public function Carrito()
    {
        $user = Auth::user();
        $this->cart = tmpSolicitudes::where('user', $user->id)->orderBy('id', 'desc')->get();
        $this->total = tmpSolicitudes::where('user', $user->id)->get()->sum('total');
        $this->itemsQuantity = tmpSolicitudes::where('user', $user->id)->get()->sum('cantidad');
        foreach ($this->cart as $item) {
            $this->can[$item->id] = $item->cantidad;
            $this->uni[$item->id] = $item->unidad;
        }
    }

    public function paginationView()
    {
        return 'vendor.livewire.bootstrap';
    }

    public function render()
    {
        $user = Auth::user();
        $this->liveSearch();
        return view('livewire.existencias.solicitudes')->extends('layouts.theme.app')->section('content');
    }

    protected $listeners = [
        'scan-code' => 'ScanCode',
        'removeItem' => 'removeItem',
        'clearCart' => 'clearCart',
        'Store' => 'Store',
        'scan-code-byid' => 'ScanCodeById',
        'print-ticket' => 'printTicket',
        'loadExistencias' => 'loadExistencias',
        'resetSearch' => 'resetSearch',
    ];

    public function ScanCodeById(Productos $product)
    {
        $this->increaseQty($product->id);
    }

    public function ScanCode($barcode, $cant = 1)
    {
        $user = Auth::user();
        $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')->join('inventarios as i', 'i.producto', 'productos.id')->where('p.codebar', $barcode)->where('i.sucursal', $user->sucursal)->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'p.cantidad', 'i.sucursal', 'p.presentacion')->first();

        if ($product == null) {
            $this->emit('scan-notfound', 'El producto no esta registrado');
        } else {
            if ($this->InCart($product->id)) {
                $this->increaseQty($product->id);
                return;
            }

            $tmp = tmpSolicitudes::create([
                'codebar' => $product->codebar,
                'producto' => $product->id,
                'name' => $product->nombreProducto,
                'cantidad' => $cant,
                'costo' => $product->costosiva,
                'total' => $product->costosiva * $cant,
                'unidad' => $product->medida,
                'medida' => $product->presentacion,
                'limit' => $product->cantidad,
                'descargar' => $cant * $product->cantidad,
                'user' => $user->id,
            ]);
            $this->Carrito();
            // return Redirect::to('/solicitudes');
        }
    }

    public function InCart($productId)
    {
        $user_id = Auth::user()->id;

        $exist = tmpSolicitudes::where('producto', $productId)->where('user', $user_id)->first();
        if ($exist) {
            return true;
        } else {
            return false;
        }
    }

    public function increaseQty($productId, $cant = 1)
    {
        $user = Auth::user();

        $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')->join('inventarios as i', 'i.producto', 'productos.id')->where('p.producto', $productId)->where('p.cantidad', 1)->whereNull('p.deleted_at')->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'p.cantidad', 'i.sucursal', 'p.presentacion')->first();

        if (!$product) {
            session()->flash('error', 'Producto no encontrado');
            return;
        }

        $exist = tmpSolicitudes::where('producto', $productId)->where('user', $user->id)->first();

        if ($exist) {
            $this->emit('item-info', 'El producto ya está cargado en el carrito');
            return;
        }

        // Si no existe, crear el nuevo registro
        $tmp = tmpSolicitudes::create([
            'codebar' => $product->codebar,
            'producto' => $product->id,
            'name' => $product->nombreProducto,
            'cantidad' => $cant,
            'costo' => $product->costosiva,
            'total' => $product->costosiva * $cant,
            'unidad' => $product->medida,
            'medida' => $product->presentacion,
            'limit' => $product->cantidad,
            'descargar' => $cant * $product->cantidad,
            'user' => $user->id,
        ]);

        $this->Carrito();
        $this->emit('focus-input', ['id' => $tmp->id]);
        // return Redirect::to('/solicitudes');
    }

    public function updateQty($id)
    {
        $user = Auth::user();

        $cantidades = $this->can[$id];
        $exist = tmpSolicitudes::find($id);

        if ($this->origen) {
            $validacionCantidad = Inventarios::where('producto', $exist->producto)->where('sucursal', $this->origen)->first();

            if ($cantidades <= $validacionCantidad->existencia) {
                $exist->cantidad = $cantidades;
                $exist->descargar = $cantidades;
                $exist->total = $cantidades * $exist->costo;
                $exist->save();
            } else {
                $this->emit('item-error', 'Producto insuficiente para trasladar');
            }
        } else {
            $this->emit('item-error', 'Seleccione la Sucursal de Entrega');
        }

        $this->Carrito();
    }

    public function updateUni($id)
    {
        if ($this->origen) {
            $user_id = Auth::user()->id;
            $uniNew = $this->uni[$id];
            $exist = tmpSolicitudes::find($id);
            $PreCan = Precios::where('medida', $uniNew)->where('producto', $exist->producto)->first();
            $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')->join('inventarios as i', 'i.producto', 'productos.id')->where('p.producto', $exist->producto)->where('p.medida', $uniNew)->where('i.sucursal', $this->origen)->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'p.cantidad', 'i.sucursal', 'p.id as idpre')->first();
            $quantity = $exist->cantidad;
            $price = $PreCan->costosiva;

            $ingresoCantidad = $PreCan->cantidad * $exist->cantidad;
            $exist->cantidad = $ingresoCantidad;
            $exist->costo = $product->costosiva / $product->cantidad;
            $exist->limit = $PreCan->cantidad;
            //$exist->newcosto = $product->costosiva;
            $exist->unidad = $uniNew;
            $exist->descargar = $ingresoCantidad;
            $exist->total = $exist->costo * $exist->cantidad;
            $exist->save();
        } else {
            $this->emit('item-error', 'Seleccione la Sucursal de Entrega');
        }
        $this->Carrito();
    }

    public function removeItem($id)
    {
        $delete = tmpSolicitudes::find($id)->delete();
        $this->Carrito();
    }

    public function clearCart()
    {
        $user_id = Auth::user()->id;
        $delete = tmpSolicitudes::where('user', $user_id)->delete();
        $this->Carrito();
    }

    public function Store()
    {
        $rules = [
            'origen'  => 'required',
            'destino' => 'required',
            'fecha'   => 'required',
        ];

        $messages = [
            'origen.required'  => 'Seleccione la sucursal de origen',
            'destino.required' => 'Seleccione el destino de la solicitud',
            'fecha.required'   => 'La fecha es requerida',
        ];

        $this->validate($rules, $messages);

        // Bloqueo modo híbrido: no se puede despachar desde una sucursal local via VPS
        if (\App\Helpers\SistemaHelper::operacionBloqueada((int) $this->origen)) {
            $this->emit('item-error', 'La sucursal origen opera en modo local. Crea la solicitud desde la PC local.');
            return;
        }

        $user = Auth::user();

        // =====================================================
        // 1) CARGAR CARRITO UNA SOLA VEZ (fuera de transacción)
        // =====================================================
        $items = tmpSolicitudes::where('user', $user->id)->get();

        if ($items->isEmpty()) {
            $this->emit('item-error', 'No hay productos en el carrito.');
            return;
        }

        DB::beginTransaction();

        try {
            // =====================================================
            // 2) CABECERA DE SOLICITUD
            // =====================================================
            $soli = Solicitudes::create([
                'origen'      => $this->origen,
                'destino'     => $this->destino,
                'numero'      => $this->correlativo,
                'fecha'       => $this->fecha,
                'detalle'     => $this->detalle,
                'solicitante' => $user->id,
                'estado'      => 'Despachado',
            ]);

            // Cargar nombres de sucursales una sola vez
            $sucur = Sucursales::find($this->origen);
            $des   = Sucursales::find($this->destino);

            // =====================================================
            // 3) PRE-CARGAR INVENTARIOS CON LOCK
            // =====================================================
            $productoIds = $items->pluck('producto')->unique()->values();

            $inventarios = Inventarios::whereIn('producto', $productoIds)
                ->where('sucursal', $this->origen)
                ->lockForUpdate()
                ->get()
                ->keyBy('producto');

            $now        = now();
            $kardexRows = [];

            // =====================================================
            // 4) LOOP DE ITEMS
            // =====================================================
            foreach ($items as $item) {

                SolicitudesDetalles::create([
                    'solicitud'  => $soli->id,
                    'producto'   => $item->producto,
                    'origen'     => $this->origen,
                    'destino'    => $this->destino,
                    'cantidad'   => $item->cantidad,
                    'costo'      => $item->costo,
                    'total'      => $item->cantidad * $item->costo,
                    'realizado'  => $user->id,
                    'autorizado' => $user->id,
                    'despachado' => $user->id,
                    'ingresado'  => $user->id,
                    'estado'     => 'Despachado',
                ]);

                $inv = $inventarios->get($item->producto);

                if (!$inv) {
                    throw new Exception("No se encontró inventario para el producto {$item->producto}");
                }

                if ($inv->existencia < $item->cantidad) {
                    throw new Exception("Existencia insuficiente para el producto {$item->producto}");
                }

                // ✅ Decrement atómico
                Inventarios::where('id', $inv->id)
                    ->decrement('existencia', $item->cantidad);

                $newExis = $inv->existencia - $item->cantidad;

                $kardexRows[] = [
                    'producto'        => $item->producto,
                    'inventario'      => $inv->id,
                    'descripcion'     => 'Despacho de producto de la sucursal ' . $sucur->nombre . ' para la sucursal ' . $des->nombre . ', realizado por ' . $user->name,
                    'fecha'           => date('Y-m-d'),
                    'hora'            => date('H:i:s'),
                    'ingresoCantidad' => 0,
                    'ingresoValor'    => 0,
                    'egresoCantidad'  => $item->cantidad,
                    'egresoValor'     => $item->cantidad * $item->costo,
                    'saldoCantidad'   => $newExis,
                    'saldoValor'      => $newExis * $item->costo,
                    'sincro_id'       => Str::uuid(),
                    'created_at'      => $now,
                    'updated_at'      => $now,
                ];
            } 

            // =====================================================
            // 5) INSERTAR KARDEX EN BLOQUE
            // =====================================================
            if (!empty($kardexRows)) {
                Kardex::insert($kardexRows);
            }

            DB::commit();

            // 🔥 Sync inmediato en segundo plano (Windows: start "" /B es la sintaxis correcta)
            $php     = PHP_BINARY;
            $artisan = base_path('artisan');
            $cmd     = 'start "" /B ' . escapeshellarg($php) . ' ' . escapeshellarg($artisan) . ' sync:solicitudes';
            pclose(popen($cmd, 'r'));

            $this->origen  = null;
            $this->destino = null;
            $this->detalle = null;
            session()->forget('origen');
            session()->forget('destino');
            session()->forget('detalle');
            $this->clearCart();
            $this->emit('item-added', 'Solicitud Registrada, pendiente de Autorización');
            $this->resetUI();

        } catch (Exception $e) {
            DB::rollBack();
            $this->emit('scan-notfound', $e->getMessage());
        }
    }

    public function resetUI()
    {
        $this->origen = '';
        //$this->origen1 = '';
        $this->destino = '';
        $this->destino1 = '';
        $this->search = '';
        $this->correlativo = '';
        $this->fecha = '';
        $this->detalle = '';
        $this->itemsQuantity = '';
        $this->total = '';
        $this->can = [];
        $this->empre = '';
        $this->sucu = '';
        $this->ca = '';
        //$this->rol = '';
        $this->selected_id = 0;
        $this->resetValidation();
        $this->resetPage();
    }

    // MODAL PRODUCTOS

    public function mostrarInfoProducto($id)
    {
        $this->productoSeleccionado = tmpSolicitudes::find($id);
        $producto = Productos::where('nombreProducto', $this->productoSeleccionado->name)->first();

        $this->nombreProductoSeleccionado = $producto->nombreProducto;
        $this->loadExistencias($producto->id);
        $this->dispatchBrowserEvent('mostrar-modal-producto');
    }

    public function addAll()
    {
        if (count($this->products) > 0) {
            foreach ($this->products as $product) {
                $this->emit('scan-code-byid', $product->id);
            }
        }
    }

    public function loadExistencias($productId = null)
    {

        $this->detalleExistencias = []; // Limpiamos antes

        if (!$productId) return;

        $idsSucursales = $this->sucursales
            ->filter(fn($s) => !in_array($s->id, [11, 12, 14]))
            ->pluck('id');

        // dd($idsSucursales);
        // Cargamos inventarios y ventas en el backend
        $inventarios = Inventarios::where('producto', $productId)
            ->whereIn('sucursal', $idsSucursales)
            ->pluck('existencia', 'sucursal');

        $ventasResumen = VentasResumen::where('producto', $productId)
            ->whereIn('sucursal', $idsSucursales)
            ->get()
            ->keyBy('sucursal');

        foreach ($this->sucursales as $sucursal) {
            $id = $sucursal->id;
            $existencia = $inventarios[$id] ?? 0;
            $ventas30 = $ventasResumen[$id]->cantidad_30 ?? 0;
            $ventas90 = $ventasResumen[$id]->cantidad_90 ?? 0;

            $color = match (true) {
                $ventas30 == 0 && $existencia == 0 => '#d1d1cf',
                $existencia == 0 && $ventas90 > 0 => '#46ed2f',
                $existencia >= $ventas30 => '#ffffff',
                $existencia < $ventas30 => '#ffff00',
                $existencia > $ventas90 * 3 => '#e44141',
                default => '#ffffff',
            };

            $this->detalleExistencias[$id] = [
                'existencia' => $existencia,
                'ventas30' => $ventas30,
                'ventas90' => $ventas90,
                'color' => $color,
            ];
        }
    }

    public function liveSearch()
    {
        $user = Auth::user();

        if (strlen($this->search) > 0) {
            $this->reset('products'); // Limpia la variable antes de actualizar
            if ($user->profile == 'Auditor' || ($user->profile == 'Super' && $this->origen)) {
                $this->products = Productos::join('categorias as c', 'c.id', 'productos.categoria')
                    ->join('medidas as m', 'm.id', 'productos.medida')
                    ->join('inventarios as i', 'i.producto', 'productos.id')
                    ->select('productos.id', 'm.unidad as medida', 'productos.nombreProducto', 'productos.codebar1', 'productos.codebar3', 'productos.codealternativo', 'i.existencia')
                    ->where('i.sucursal', $this->origen)
                    ->where('productos.activo', 1)
                    ->where(function ($query) {
                        $query
                            ->where('productos.nombreProducto', 'like', "%{$this->search}%")
                            ->orWhere('productos.codebar1', 'like', "%{$this->search}%")
                            ->orWhere('productos.codebar2', 'like', "%{$this->search}%")
                            ->orWhere('productos.codebar3', 'like', "%{$this->search}%")
                            ->orWhere('productos.codealternativo', 'like', "%{$this->search}%");
                    })
                    ->groupBy('productos.id', 'm.unidad', 'productos.nombreProducto', 'productos.codebar1', 'productos.codebar3', 'productos.codealternativo', 'i.existencia')
                    ->orderBy('productos.nombreProducto', 'asc')
                    ->take(50)
                    ->get();
            } else {
                $this->products = Productos::join('categorias as c', 'c.id', 'productos.categoria')
                    ->join('medidas as m', 'm.id', 'productos.medida')
                    ->join('inventarios as i', 'i.producto', 'productos.id')
                    ->select('productos.id', 'm.unidad as medida', 'productos.nombreProducto', 'productos.codebar1', 'productos.codebar3', 'productos.codealternativo', 'i.existencia')
                    ->where('i.sucursal', $user->sucursal)
                    ->where('productos.activo', 1)
                    ->where(function ($query) {
                        $query
                            ->where('productos.nombreProducto', 'like', "%{$this->search}%")
                            ->orWhere('productos.codebar1', 'like', "%{$this->search}%")
                            ->orWhere('productos.codebar2', 'like', "%{$this->search}%")
                            ->orWhere('productos.codebar3', 'like', "%{$this->search}%")
                            ->orWhere('productos.codealternativo', 'like', "%{$this->search}%");
                    })
                    ->groupBy('productos.id', 'm.unidad', 'productos.nombreProducto', 'productos.codebar1', 'productos.codebar3', 'productos.codealternativo', 'i.existencia')
                    ->orderBy('productos.nombreProducto', 'asc')
                    ->take(50)
                    ->get();
            }
        } else {
            $this->products = [];
        }
    }

    public function Add($id)
    {
        $this->emit('scan-code-byid', $id);
        // $this->search = '';
        $this->existencias = collect();
        $this->productoSeleccionado = null;
    }

    public function resetSearch()
    {
        $this->search = ''; // Limpiar el campo de búsqueda en Livewire
        $this->existencias = [];
        $this->products = [];
    }

    public function updatedOrigen($value)
    {
        session(['origen' => $value]);
    }

    public function updatedDestino($value)
    {
        session(['destino' => $value]);
    }

    public function updatedDetalle($value)
    {
        session(['detalle' => $value]);
    }
}
