<?php

namespace App\Http\Livewire;

use App\Models\ActividadEconomica;
use App\Models\Compras;
use App\Models\ComprasDetalles;
use App\Models\CuentasPagar;
use App\Models\Departamentos;
use App\Models\Distritos;
use App\Models\Facturadores;
use App\Models\Inventarios;
use App\Models\Kardex;
use App\Models\Municipios;
use App\Models\Notificacion;
use App\Models\Pagos;
use App\Models\Precios;
use App\Models\Productos;
use App\Models\Proveedores;
use App\Models\Sucursales;
use App\Models\tipoCompras;
use App\Models\TipoPersona;
use App\Models\tmpCompras;
use App\Models\User;
use App\Services\BitacoraPrecios;
use Carbon\Carbon;
use Darryldecode\Cart\Cart;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;
use Livewire\Component;

class NuevaCompraController extends Component
{
    ///variables para el diseño
    public  $pageTitle, $componentName;

    //para agegar un proveedor
    public $nombre, $tipoPersona, $direccion, $telefono, $correo, $registro, $nit,
        $departamento, $municipio, $distrito, $actividad, $giro, $search, $selected_id, $departamentos, $municipios, $distritos, $proveedorAddSelectId, $proveedorAddSelectName, $select_id, $personas, $actividades, $sucursales, $sucursal, $categoria, $proveedorCompras;

    //para los datos de los productos
    public $total, $itemsQuantity, $fechaV = [], $can = [], $pri = [], $totals = [], $uni = [], $medis = [], $percepcion = 0, $subtotal, $iva, $totales;

    // para guardar la compra
    public $proveedorSelectId, $proveedorSelectName, $proveedorCompra, $factura, $correlativo, $serie, $fecha, $condiPago, $vendedor, $generacion;

    public function mount()
    {
        $user = Auth::user();

        $this->pageTitle = 'Nueva';
        $this->componentName = 'Compras';
        $this->fecha = Carbon::now()->format('Y-m-d');
        $this->personas = TipoPersona::all();
        $this->actividades = ActividadEconomica::all();
        $this->departamentos = Departamentos::all();
        $this->municipios = Municipios::all();
        $this->distritos = Distritos::all();

        if ($user->profile == 'Super' || $user->profile == 'Administrador') {
            $this->sucursales = Sucursales::all();
        } else {
            $this->sucursales = Sucursales::where('id', $user->sucursal)->get();
            foreach ($this->sucursales as $s) {
                $this->sucursal = $s->id;
            }
        }

        $this->cargaData();
    }

    public function updatedFactura()
    {
        $this->generarCostos(); // Ejecutar cuando se cambia la factura
        $this->cargaData();
    }

    public function paginationView()
    {
        return 'vendor.livewire.bootstrap';
    }

    public function render()
    {
        $user_id = Auth::user()->id;
        $proveedor = Proveedores::all();
        $tipos = tipoCompras::all();
        $cart = tmpCompras::where('usuario', $user_id)->orderBy('id', 'desc')->get();
        return view('livewire.compras.nueva-compra', ['proveedores' => $proveedor, 'tipos' => $tipos, 'cart' =>  $cart])
            ->extends('layouts.theme.app')
            ->section('content');
    }

    public function SaveProveedor()
    {
        $rules = [
            'nombre' => "required|unique:proveedores|min:3",
            'tipoPersona' => 'required|not_in:Elegir TipoPersona',
            'telefono' => "required|unique:proveedores|min:3",
            'nit' => "numeric|unique:proveedores|min:3",
            'registro' => 'numeric',
            'departamento' => 'required|not_in:Elegir Departamento',
            'municipio' => 'required|not_in:Elegir Municipio',
            'distrito' => 'required|not_in:Elegir Distrito',
            //'giro' => "required|min:3",
            'proveedorAddSelectId' => 'required'
        ];

        $messages = [
            'proveedorAddSelectId.required' => 'La Actividad Econimica es Requerida',
            'nombre.required' => 'El Nombre del Proveedor es requerido',
            'nombre.unique' => 'El Nombre del Proveedor ya existe',
            'nombre.min' => 'El Nombre del Proveedor debe tener mas de 3 caracteres',
            'tipoPersona.not_in' => 'El tipo de persona es Requerido',
            'telefono.required' => 'El Numero de telefono es requerido',
            'telefono.unique' => 'El numero de telefono ya existe',
            'telefono.min' => 'El numero de telefono debe tener mas de 3 caracteres',
            'registro.numeric' => 'El Numero de registro es numerico',
            //'nit.required' => 'El Numero de NIT es requerido',
            'nit.unique' => 'El Numero de NIT ya existe',
            'nit.min' => 'El Numero de NIT debe tener mas de 3 caracteres',
            'departamento.not_in' => 'El departamento es Requerido',
            'municipio.not_in' => 'El municipio es Requerido',
            'distrito.not_in' => 'El distrito es Requerido',
            //'giro.required' => 'El Giro del Proveedor es requerido',
            //'giro.min'=> 'El Giro del Proveedor debe tener mas de 3 caracteres',
            'nit.numeric' => 'El numero de Registro tiene que ser numerico',
        ];

        $this->validate($rules, $messages);

        $pro = Proveedores::create([
            'nombre' => $this->nombre,
            'tipoPersona' => $this->tipoPersona,
            'direccion' => $this->direccion,
            'telefono' => $this->telefono,
            'correo' => $this->correo,
            'registro' => $this->registro,
            'nit' => $this->nit,
            'departamento' => $this->departamento,
            'municipio' => $this->municipio,
            'distrito' => $this->distrito,
            'actividad' => $this->proveedorAddSelectId,
            'giro' => $this->giro,
            'desActividad' => $this->proveedorAddSelectName,
            'categoria' => $this->categoria
        ]);


        $this->ResetPro();
        $this->emit('item-added', 'Proveedor Registrado');
    }

    public function ResetPro()
    {
        $this->nombre = '';
        $this->direccion = '';
        $this->telefono = '';
        $this->correo = '';
        $this->registro = '';
        $this->nit = '';
        $this->departamento = 'Elegir Departamento';
        $this->tipoPersona = 'Elegir Tipo de Persona';
        $this->municipio = 'Elegir Municipio';
        $this->distrito = 'Elegir distrito';
        $this->actividad = ' Elegir Actividad Economica';
        $this->giro = '';
        $this->departamento = '';
        $this->municipio = '';
        $this->distrito = '';
        $this->proveedorAddSelectId = '';
        $this->proveedorAddSelectName = '';
    }

    protected $listeners = [
        'scan-code' => 'ScanCode',
        'removeItem' => 'removeItem',
        'clearCart' => 'clearCart',
        'Store' => 'Store',
        'scan-code-byid' => 'ScanCodeById',
        'print-ticket' => 'printTicket'
    ];

    public function ScanCodeById($product)
    {
        $this->increaseQty($product);
    }

    public function ScanCode($barcode, $cant = 1)
    {
        $user = Auth::user();

        // Primero intentar precio unitario (cantidad=1) directo por barcode
        $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
            ->join('inventarios as i', 'i.producto', 'productos.id')
            ->where('p.codebar', $barcode)
            ->where('p.cantidad', 1)
            ->where('i.sucursal', $user->sucursal)
            ->whereNull('p.deleted_at')
            ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'p.cantidad', 'i.sucursal', 'p.id as precio')
            ->first();

        // Si el barcode es de caja/fardo, buscar el precio unitario del mismo producto
        if (!$product) {
            $precioOrigen = \App\Models\Precios::where('codebar', $barcode)
                ->whereNull('deleted_at')
                ->first();

            if ($precioOrigen) {
                $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
                    ->join('inventarios as i', 'i.producto', 'productos.id')
                    ->where('p.producto', $precioOrigen->producto)
                    ->where('p.cantidad', 1)
                    ->where('i.sucursal', $user->sucursal)
                    ->whereNull('p.deleted_at')
                    ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'p.cantidad', 'i.sucursal', 'p.id as precio')
                    ->first();
            }
        }

        if ($product) {
            $this->increaseQty($product->precio);
        } else {

            // $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
            //     ->join('inventarios as i', 'i.producto', 'productos.id')
            //     ->where('p.codebar', 'like', '%' . $barcode . '%')
            //     //->where('i.sucursal', $user->sucursal)
            //     ->whereNull('p.deleted_at')
            //     ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'i.sucursal', 'p.id as idpre', 'p.costociva')
            //     ->first();
            //$p = Precios::find($id);
            /*$insert = Inventarios::create([
                    'producto' => $product->id,
                    'empresa' => $user->empresa,
                    'sucursal' => $user->sucursal,
                    'existencia' => 0
                ]);

                $kardex = Kardex::create([
                    'producto' => $product->id,
                    'inventario' => $insert->id,
                    'descripcion' => 'Nuevo producto',
                    'fecha' => date('Y-m-d'),
                    'hora' => date('H:i:s'),
                    'ingresoCantidad' => 0.00,
                    'ingresoValor' => 0.00,
                    'egresoCantidad' => 0.00,
                    'egresoValor' => 0.00,
                    'saldoCantidad' => 0.00,
                    'saldoValor' => 0.00
                ]);*/

            // $this->increaseQty($product->precio);
            $this->emit('scan-notfound', 'Producto no encontrado');
        }
    }

    public function InCart($productoId)
    {
        return tmpCompras::where('usuario', Auth::id())
            ->where('producto', $productoId)
            ->exists();
    }

    public function increaseQty($id, $cant = 1)
    {

        $user = Auth::user();

        $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
            ->join('inventarios as i', 'i.producto', 'productos.id')
            ->where('p.id', $id)
            ->whereNull('p.deleted_at')
            ->where('i.sucursal', $user->sucursal)
            ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'i.sucursal', 'p.id as idpre', 'p.costociva', 'p.medida as uni', 'p.cantidad')
            ->first();

        if ($product) {

            if ($this->factura == 1 ||  $this->factura == 4) {
                $costo = $product->costosiva;
            } else {
                $costo = $product->costociva;
            }

            $tmp = tmpCompras::create([
                'producto' => $product->id,
                'name' => $product->nombreProducto,
                'price' => $costo,
                'newcosto' => 0.00,
                'quantity' => $cant,
                'sucursal' => $product->sucursal,
                'codebar' => $product->codebar,
                'vencimiento' => null,
                'total' => $costo * $cant,
                'medida' => $product->uni,
                'ingreso' => $cant,
                'limit' => $product->cantidad,
                'costouni' => (float) $costo / (float) $product->cantidad,
                'idpre' => $product->idpre,
                'usuario' => $user->id
            ]);
        } else {
            // $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
            //     ->join('inventarios as i', 'i.producto', 'productos.id')
            //     ->where('p.id', $id)
            //     //->where('i.sucursal', $user->sucursal)
            //     ->whereNull('p.deleted_at')
            //     ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'i.sucursal', 'p.id as idpre', 'p.costociva')
            //     ->first();
            //$p = Precios::find($id);
            /*$insert = Inventarios::create([
                'producto' => $product->id,
                'empresa' => $user->empresa,
                'sucursal' => $user->sucursal,
                'existencia' => 0
            ]);

            $kardex = Kardex::create([
                'producto' => $product->id,
                'inventario' => $insert->id,
                'descripcion' => 'Nuevo producto',
                'fecha' => date('Y-m-d'),
                'hora' => date('H:i:s'),
                'ingresoCantidad' => 0.00,
                'ingresoValor' => 0.00,
                'egresoCantidad' => 0.00,
                'egresoValor' => 0.00,
                'saldoCantidad' => 0.00,
                'saldoValor' => 0.00
             ]);*/

            // $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
            //     ->join('inventarios as i', 'i.producto', 'productos.id')
            //     ->where('p.id', $id)
            //     ->whereNull('p.deleted_at')
            //     //->where('i.sucursal', $user->sucursal)
            //     ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'i.sucursal', 'p.id as idpre', 'p.costociva')
            //     ->first();

            // if ($this->factura == 1) {
            //     $costo = $product->costosiva;
            // } else {
            //     $costo = $product->costociva;
            // }

            // $tmp = tmpCompras::create([
            //     'producto' => $product->id,
            //     'name' => $product->nombreProducto,
            //     'price' => $costo,
            //     'newcosto' => 0.00,
            //     'quantity' => $cant,
            //     'sucursal' => $product->sucursal,
            //     'codebar' => $product->codebar,
            //     'vencimiento' => null,
            //     'total' => $costo * $cant,
            //     'medida' => $product->medida,
            //     'ingreso' => $cant,
            //     'idpre' => $product->idpre,
            //     'usuario' => $user->id
            // ]);

            $this->emit('scan-notfound', 'Producto no encontrado');
        }
        $this->cargaData();
        //$this->emit('focus-input', ['id' => $tmp->id]);
    }

    public function updateQty($id)
    {
        $cantidades = $this->can[$id];

        $user_id = Auth::user()->id;

        $exist = tmpCompras::where('usuario', $user_id)->find($id);

        // Usar el limit guardado en el carrito (siempre 1 para compras unitarias)
        $exist->quantity = $cantidades;
        $exist->total    = $cantidades * $exist->price;
        $exist->ingreso  = $exist->limit * $cantidades;
        $exist->save();
        $this->cargaData();
    }

    public function removeItem($id)
    {
        $user_id = Auth::user()->id;

        tmpCompras::destroy($id);
        $this->cargaData();
    }

    public function clearCart()
    {
        $user_id = Auth::user()->id;
        tmpCompras::where('usuario', $user_id)->delete();
        $this->cargaData();
    }

    public function updateFV($id)
    {
        $user_id = Auth::user()->id;
        $fehcaVencimiento = $this->fechaV[$id];

        $exist = tmpCompras::find($id);
        $exist->vencimiento = $fehcaVencimiento;
        $exist->save();

        $this->cargaData();
    }

    public function updateTotal($id)
    {
        $user_id = Auth::user()->id;
        $tot = $this->totals[$id];

        $exist = tmpCompras::find($id);
        $exist->total    = $tot;
        $exist->price    = $tot / $exist->quantity;
        $exist->newcosto = $tot / $exist->quantity;
        $exist->save();

        $this->cargaData();
    }


    public function updatePre($id)
    {
        $user_id = Auth::user()->id;
        $priceNew = $this->pri[$id];

        $exist = tmpCompras::find($id);

        // Verificacion de limite de precio
        $searchPrice = Precios::find($exist->idpre);

        if($this->factura == 1 || $this->factura == 4){
            $limite = $searchPrice->costosiva * 0.30;
            if($priceNew > ($searchPrice->costosiva + $limite)){
                $this->emit('item-error', 'Los parámetros del costo están muy altos, porfavor revisar los costos de factura');
                return;
            };
        }
        elseif($this->factura == 2 || $this->factura == 3){
            $limite = $searchPrice->costociva * 0.30;
            if($priceNew > ($searchPrice->costociva + $limite)){
                $this->emit('item-error', 'Los parámetros del costo están muy altos, porfavor revisar los costos de factura');
                return;
            };
        }

        $exist->newcosto = $priceNew;
        $exist->total = $priceNew * $exist->quantity;
        $exist->costouni = $priceNew / $exist->limit;
        $exist->save();

        $this->cargaData();
    }

    public function updateUni($id)
    {
        $user_id = Auth::user()->id;
        $uniNew = $this->uni[$id];
        $exist = tmpCompras::find($id);
        $PreCan = Precios::where('medida', $uniNew)->where('producto', $exist->producto)->whereNull('deleted_at')->first();
        $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
            ->join('inventarios as i', 'i.producto', 'productos.id')
            ->whereNull('p.deleted_at')
            ->where('p.producto', $exist->producto)
            ->where('p.medida', $uniNew)
            //->where('i.sucursal', session('sucursal'))
            ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'p.cantidad', 'i.sucursal', 'p.id as idpre')
            ->first();
        $ingresoCantidad = $PreCan->cantidad * $exist->quantity;
        $exist->price = $product->costosiva;
        $exist->newcosto = $product->costosiva;
        $exist->medida = $uniNew;
        $exist->ingreso = $ingresoCantidad;
        $exist->total = $product->costosiva * $exist->quantity;
        $exist->idpre = $product->idpre;
        $exist->limit = $product->cantidad;
        $exist->costouni = $exist->newcosto / $product->cantidad;
        $exist->save();

        $this->cargaData();
    }

    public function Store()
    {
        $user_id = Auth::user()->id;
        $user    = Auth::user();

        $horaActual = date('H:i:s');

        $rules = [
            'proveedorSelectId' => 'required',
            'factura'           => 'required|not_in:Elegir',
            'correlativo'       => 'required',
            'fecha'             => 'required',
            'condiPago'         => 'required|not_in:Elegir',
            'sucursal'          => 'required|not_in:Elegir',
            'generacion'        => 'required'
        ];

        $messages = [
            'proveedorSelectId.required' => 'El nombre del proveedor es requerido',
            'factura.required'           => 'El campo factura es requerido',
            'factura.not_in'             => 'Elige un tipo de factura diferente de Elegir',
            'correlativo.required'       => 'Digite el correlativo de la factura',
            'generacion.required'        => 'Digite el N° generacion de la factura',
            'fecha.required'             => 'El campo fecha es requerido',
            'condiPago.required'         => 'El campo condicion de pago es requerido',
            'condiPago.not_in'           => 'Elige una condicion de pago diferente de Elegir',
            'sucursal.required'          => 'La sucursal es requerido',
            'sucursal.not_in'            => 'Elige una sucursal diferente de Elegir',
        ];
        $this->validate($rules, $messages);

        // Bloqueo modo híbrido: no se puede registrar compras a una sucursal local desde el VPS
        if (\App\Helpers\SistemaHelper::operacionBloqueada((int) $this->sucursal)) {
            $this->emit('item-error', 'La sucursal seleccionada opera en modo local. Registra la compra desde la PC local.');
            return;
        }

        // =====================================================
        // 1) CARGAR CARRITO UNA SOLA VEZ (fuera de transacción)
        // =====================================================
        $items = tmpCompras::where('usuario', $user_id)->get();

        if ($items->isEmpty()) {
            $this->emit('item-error', 'No hay productos en el carrito.');
            return;
        }

        $ultimoNumeroCompra = Compras::orderBy('numero', 'desc')->select('numero')->first();
        $nuevoNumeroCompra  = $ultimoNumeroCompra ? ($ultimoNumeroCompra->numero + 1) : 1;

        $estadoPago = ($this->condiPago === 'Credito') ? 'Pendiente' : 'Pagada';

        $subtotal = $items->sum('total');

        if ($this->factura == 1) {
            $sub = $subtotal * 1.13;
            $iva = $sub - $subtotal;
        } else {
            $iva = 0.00;
        }

        if ($this->factura == 2) {
            $total = $subtotal + $this->percepcion;
        } else {
            $total = $subtotal + $iva + $this->percepcion;
        }

        DB::beginTransaction();

        try {
            // =====================================================
            // 2) CABECERA DE COMPRA
            // =====================================================
            $compra = Compras::create([
                'numero'     => $nuevoNumeroCompra,
                'tipo'       => $this->factura,
                'correlativo'=> $this->correlativo,
                'serie'      => $this->serie,
                'fecha'      => $this->fecha,
                'condi_pago' => $this->condiPago,
                'vendedor'   => $this->vendedor,
                'estado'     => $estadoPago,
                'fechaPago'  => null,
                'proveedor'  => $this->proveedorSelectId,
                'user'       => $user_id,
                'sucursal'   => $this->sucursal,
                'total'      => $total,
                'subtotal'   => $subtotal,
                'iva'        => $iva,
                'percepcion' => $this->percepcion,
                'generacion' => $this->generacion,
            ]);

            // =====================================================
            // 3) PRE-CARGAR INVENTARIOS CON LOCK
            // =====================================================
            $productoIds = $items->pluck('producto')->unique()->values();

            $inventarios = Inventarios::whereIn('producto', $productoIds)
                ->where('sucursal', $this->sucursal)
                ->lockForUpdate()
                ->get()
                ->keyBy('producto');

            $now        = now();
            $kardexRows = [];

            // Detectar si es Nota de Crédito (revierte inventario en lugar de sumar)
            $tipoNombre     = tipoCompras::find($this->factura)?->tipo ?? '';
            $esNotaCredito  = str_contains(strtolower($tipoNombre), 'nota') && str_contains(strtolower($tipoNombre), 'cr');

            // =====================================================
            // 4) LOOP DE ITEMS
            // =====================================================
            foreach ($items as $item) {

                $venci = (empty($item->vencimiento) || $item->vencimiento == '0000-00-00')
                    ? null
                    : $item->vencimiento;

                $costo = ($item->newcosto == 0.00) ? $item->price : $item->newcosto;

                ComprasDetalles::create([
                    'compra'          => $compra->id,
                    'producto'        => $item->producto,
                    'medida'          => $item->medida,
                    'cantidad'        => $item->quantity,
                    'ingreso'         => $item->ingreso,
                    'costo'           => $costo,
                    'total'           => $item->total,
                    'fechaVencimiento'=> $venci,
                ]);

                $inv = $inventarios->get($item->producto);

                if (!$inv) {
                    throw new \RuntimeException("No existe inventario para el producto {$item->producto}");
                }

                if ($esNotaCredito) {
                    // Nota de Crédito: RESTAR inventario
                    Inventarios::where('id', $inv->id)
                        ->decrement('existencia', $item->ingreso);
                    $nuevaExistencia = max(0, $inv->existencia - $item->ingreso);
                    $kardexRows[] = [
                        'producto'        => $item->producto,
                        'inventario'      => $inv->id,
                        'descripcion'     => 'Nota de Crédito proveedor ' . $this->proveedorSelectName . ' N° ' . $this->correlativo . ', registrado por ' . $user->name,
                        'fecha'           => $this->fecha,
                        'hora'            => $horaActual,
                        'ingresoCantidad' => 0,
                        'ingresoValor'    => 0,
                        'egresoCantidad'  => $item->ingreso,
                        'egresoValor'     => $item->costouni * $item->ingreso,
                        'saldoCantidad'   => $nuevaExistencia,
                        'saldoValor'      => $item->costouni * $nuevaExistencia,
                        'sincro_id'       => Str::uuid(),
                        'created_at'      => $now,
                        'updated_at'      => $now,
                    ];
                } else {
                    // Compra normal: SUMAR inventario
                    Inventarios::where('id', $inv->id)
                        ->increment('existencia', $item->ingreso);
                    $nuevaExistencia = $inv->existencia + $item->ingreso;
                    $kardexRows[] = [
                        'producto'        => $item->producto,
                        'inventario'      => $inv->id,
                        'descripcion'     => 'Compra de productos a ' . $this->proveedorSelectName . ' Factura ' . $this->correlativo . ', ingresado por ' . $user->name,
                        'fecha'           => $this->fecha,
                        'hora'            => $horaActual,
                        'ingresoCantidad' => $item->ingreso,
                        'ingresoValor'    => $item->costouni * $item->ingreso,
                        'egresoCantidad'  => 0,
                        'egresoValor'     => 0,
                        'saldoCantidad'   => $nuevaExistencia,
                        'saldoValor'      => $item->costouni * $nuevaExistencia,
                        'sincro_id'       => Str::uuid(),
                        'created_at'      => $now,
                        'updated_at'      => $now,
                    ];
                }

                // ---------------------------------------------
                // Actualización de precios (no aplica en NC)
                // ---------------------------------------------
                if (!$esNotaCredito && $item->newcosto <> 0.00) {
                    $precioBase = Precios::find($item->idpre);
                    if ($precioBase) {
                        $costoBase     = (float) $item->newcosto;

                        // Si el costo de la factura es igual al registrado → no actualizar ni bitácora ni notificaciones
                        $costoExistente = ($this->factura == 1 || $this->factura == 4)
                            ? (float) $precioBase->costosiva
                            : (float) $precioBase->costociva;

                        if (round($costoBase, 4) === round($costoExistente, 4)) {
                            continue;
                        }

                        // Costo por unidad base, independiente de la medida comprada
                        $costoUnitario = $costoBase / $precioBase->cantidad;

                        $preciosList = Precios::where('producto', $item->producto)->get();
                        $ppventa = 0;

                        foreach ($preciosList as $precio) {
                            if ($this->factura == 1 || $this->factura == 4) {
                                // costoBase es sin IVA (por medida comprada)
                                $costoSivaUni = $costoUnitario;
                                $costoCivaUni = $costoUnitario * 1.13;

                                $limiteInferior = (float) $precioBase->costosiva * 0.70;
                                $limiteSuperior = (float) $precioBase->costosiva * 1.30;
                                $ppventa        = ($costoCivaUni * $precio->utilidad / 100) + $costoCivaUni;

                                if ($costoBase >= $limiteInferior && $costoBase <= $limiteSuperior) {
                                    $anterior = $precio->only(['costosiva','costociva','utilidad','pventasiva','pvventa','cantidad']);
                                    $precio->costosiva  = $costoSivaUni * $precio->cantidad;
                                    $precio->costociva  = $costoCivaUni * $precio->cantidad;
                                    $precio->pventasiva = $this->ajustarDecimal($ppventa, 2);
                                    $precio->pvventa    = $this->ajustarDecimal($ppventa * $precio->cantidad, 2);
                                    $precio->save();
                                    BitacoraPrecios::log('Actualizado', 'Compras', $precio, $anterior);

                                    if ((int) $precio->familia !== 1) {
                                        $this->actualizarPreciosFamilia($precio->familia, $precio->medida, $precio->cantidad, [
                                            'costosiva'  => $precio->costosiva,
                                            'costociva'  => $precio->costociva,
                                            'utilidad'   => $precio->utilidad,
                                            'pventasiva' => $precio->pventasiva,
                                            'pvventa'    => $precio->pvventa,
                                            'escala'     => $precio->escala,
                                        ]);
                                    }
                                }
                            } else {
                                // costoBase es con IVA (por medida comprada)
                                $costoCivaUni = $costoUnitario;
                                $costoSivaUni = $costoUnitario / 1.13;

                                $limiteInferior = (float) $precioBase->costociva * 0.70;
                                $limiteSuperior = (float) $precioBase->costociva * 1.30;
                                $ppventa        = ($costoCivaUni * $precio->utilidad / 100) + $costoCivaUni;

                                if ($costoBase >= $limiteInferior && $costoBase <= $limiteSuperior) {
                                    $anterior = $precio->only(['costosiva','costociva','utilidad','pventasiva','pvventa','cantidad']);
                                    $precio->costosiva  = $costoSivaUni * $precio->cantidad;
                                    $precio->costociva  = $costoCivaUni * $precio->cantidad;
                                    $precio->pventasiva = $this->ajustarDecimal($ppventa, 2);
                                    $precio->pvventa    = $this->ajustarDecimal($ppventa * $precio->cantidad, 2);
                                    $precio->save();
                                    BitacoraPrecios::log('Actualizado', 'Compras', $precio, $anterior);

                                    if ((int) $precio->familia !== 1) {
                                        $this->actualizarPreciosFamilia($precio->familia, $precio->medida, $precio->cantidad, [
                                            'costosiva'  => $precio->costosiva,
                                            'costociva'  => $precio->costociva,
                                            'utilidad'   => $precio->utilidad,
                                            'pventasiva' => $precio->pventasiva,
                                            'pvventa'    => $precio->pvventa,
                                            'escala'     => $precio->escala,
                                        ]);
                                    }
                                }
                            }
                        }

                        $usuarios = User::where('status', 'ACTIVE')->get();
                        foreach ($usuarios as $u) {
                            Notificacion::create([
                                'titulo'      => 'Actualizacion de Precios',
                                'descripcion' => 'Se ha actualizado el precio de venta del producto ' . $item->name . ' a $ ' . number_format($ppventa, 2),
                                'idPrecio'    => $item->idpre,
                                'idProducto'  => $item->producto,
                                'codebar'     => $item->codebar,
                                'user'        => $u->id,
                                'leido'       => 0,
                            ]);
                        }
                    }
                }
            }

            // =====================================================
            // 5) INSERTAR KARDEX EN BLOQUE
            // =====================================================
            if (!empty($kardexRows)) {
                Kardex::insert($kardexRows);
            }

            // =====================================================
            // 6) CUENTAS POR PAGAR / PAGOS
            // =====================================================
            if ($esNotaCredito) {
                // NC: registra con monto negativo para que reste en reportes
                $cuenta = CuentasPagar::create([
                    'compra'           => $compra->id,
                    'proveedor'        => $this->proveedorSelectId,
                    'monto_total'      => -$total,
                    'saldo'            => 0.00,
                    'estado'           => 'pagada',
                    'fecha_vencimiento'=> now(),
                ]);

                // Pago negativo — aparece como deducción en reportes de pagos
                $lastPago    = Pagos::orderBy('correlativo', 'desc')->lockForUpdate()->first();
                $correlativo = $lastPago ? $lastPago->correlativo + 1 : 1;

                Pagos::create([
                    'correlativo'  => $correlativo,
                    'fecha'        => $this->fecha,
                    'hora'         => $horaActual,
                    'user'         => $user_id,
                    'concepto'     => 'Nota de Crédito - ' . $this->correlativo,
                    'total'        => -$total,
                    'cuenta_pagar' => $cuenta->id,
                    'tipo_pago'    => 1,
                ]);
            } elseif ($this->condiPago === 'Credito') {
                CuentasPagar::create([
                    'compra'           => $compra->id,
                    'proveedor'        => $this->proveedorSelectId,
                    'monto_total'      => $total,
                    'saldo'            => $total,
                    'estado'           => 'pendiente',
                    'fecha_vencimiento'=> now()->addDays(30),
                ]);
            } else {
                $cuenta = CuentasPagar::create([
                    'compra'           => $compra->id,
                    'proveedor'        => $this->proveedorSelectId,
                    'monto_total'      => $total,
                    'saldo'            => 0.00,
                    'estado'           => 'pagada',
                    'fecha_vencimiento'=> now(),
                ]);  

                // ✅ Correlativo sin condición de carrera
                $lastPago    = Pagos::orderBy('correlativo', 'desc')->lockForUpdate()->first();
                $correlativo = $lastPago ? $lastPago->correlativo + 1 : 1;

                Pagos::create([
                    'correlativo'  => $correlativo,
                    'fecha'        => $this->fecha,
                    'hora'         => $horaActual,
                    'user'         => $user_id,
                    'concepto'     => 'Compra al contado - Factura ' . $this->correlativo,
                    'total'        => $total,
                    'cuenta_pagar' => $cuenta->id,
                    'tipo_pago'    => 1,
                ]);
            }

            DB::commit();

            $this->clearCart();
            $this->emit('item-added', 'Compra registrada con exito');
            $this->ResetUI();
            return Redirect::to('/compras');

        } catch (\Exception $e) {
            DB::rollBack();
            $this->emit('item-error', $e->getMessage());
        }
    }

    public function ResetUI()
    {
        $this->proveedorSelectId = '';
        $this->proveedorSelectName = '';
        $this->proveedorCompra = '';
        $this->factura = '';
        $this->correlativo = '';
        $this->serie = '';
        $this->fecha = '';
        $this->condiPago = '';
        $this->vendedor = '';
    }

    /**
     * Actualiza TODOS los precios de una familia
     * para una medida y cantidad específica
     */
    private function actualizarPreciosFamilia($familiaId, $medida, $cantidad, $datosPrecio)
    {
        // Si la familia es 1 (sin familia), no hacer nada
        if ((int) $familiaId === 1) {
            return;
        }

        // Actualizar TODOS los precios de la familia (no solo uno)
        $preciosFamilia = Precios::where('familia', $familiaId)
            ->where('medida', $medida)
            ->where('cantidad', $cantidad)
            ->get();

        foreach ($preciosFamilia as $pf) {
            $anterior = $pf->only(['costosiva','costociva','utilidad','pventasiva','pvventa','cantidad']);
            $pf->update([
                'costosiva'  => $datosPrecio['costosiva'],
                'costociva'  => $datosPrecio['costociva'],
                'utilidad'   => $datosPrecio['utilidad'],
                'pventasiva' => $datosPrecio['pventasiva'],
                'pvventa'    => $datosPrecio['pvventa'],
                'escala'     => $datosPrecio['escala'] ?? 'No',
            ]);
            BitacoraPrecios::log('Actualizado', 'Compras', $pf, $anterior);
        }
    }

    public function updateDepto()
    {
        $this->municipios = Municipios::where('departamento', $this->departamento)->get();
    }

    public function updateMuni()
    {
        $this->distritos = Distritos::where('municipio', $this->municipio)->get();
    }

    public function cargaData()
    {
        $user_id = Auth::user()->id;

        $data = tmpCompras::where('usuario', $user_id)->get();

        $this->itemsQuantity = tmpCompras::where('usuario', $user_id)->count();

        //$this->subtotal =  tmpCompras::where('usuario', $user_id)->sum('total');

        if ($this->factura == 1) {
            $s = tmpCompras::where('usuario', $user_id)->sum('total');
            $this->total = $s * 1.13;
            $this->subtotal =  $s;
            $this->iva = $this->total - $s;
            $this->totales = $s + $this->iva;
        } else {
            $this->subtotal =  $this->total;
            $this->iva = 0.00;
            $this->totales = tmpCompras::where('usuario', $user_id)->sum('total');
            $this->total = tmpCompras::where('usuario', $user_id)->sum('total');
        }

        if ($data) {
            foreach ($data as $r) {
                $this->fechaV[$r->id] = $r->vencimiento;
                $this->can[$r->id] = $r->quantity;
                $this->totals[$r->id] = $r->total;
                $this->pri[$r->id] = ($r->newcosto === null || $r->newcosto == 0.00) ? $r->price : $r->newcosto;
                $this->uni[$r->id] = $r->medida;
            }
        }
        $this->totales =  $this->total + $this->percepcion;
        $this->calcularPercepcion();
    }

    public function CalcularPercicionProveedor()
    {
        //$prove = Proveedores::find($this->proveedorSelectId);
        //dd($prove);
        //if($prove && $prove->categoria === 'GRANDE')
        //{
        //$this->percepcion = number_format(($this->total * 0.01), 2);
        //}
        //else
        //{
        //$this->percepcion = 0;
        //}
    }

    public function calcularPercepcion()
    {

        $tipoFactura = tipoCompras::find($this->factura);

        $proveedor = Proveedores::find($this->proveedorSelectId);

        if ($tipoFactura) {
            if ($proveedor && $proveedor->categoria == 'GRANDE' && $this->total >= 113) {
                if ($tipoFactura->id == 1) {
                    $this->percepcion = round($this->subtotal * 0.01, 2);
                    $this->totales = $this->subtotal + $this->percepcion + $this->iva;
                } elseif ($tipoFactura->id == 2) {
                    $operacion = $this->subtotal / 1.13;
                    $this->percepcion = round($operacion * 0.01, 2);
                    $this->totales = $this->subtotal + $this->percepcion;
                }
            } else {
                $this->percepcion = 0.00;
            }
        }
    }

    public function generarCostos()
    {
        $user = Auth::user();
        $tmp = tmpCompras::where('usuario', $user->id)->get(); // Carga todos los datos de tmpCompras
        $esFactura = ($this->factura == 1 || $this->factura == 4);

        foreach ($tmp as $t) {
            // 🔹 Obtener el precio del producto correspondiente en la tabla Precios
            $pre = Precios::where('id', $t->idpre)->first(); // Asegúrate de que la relación sea correcta

            if (!$pre) {
                continue; // 🔹 Si no encuentra el precio, omite esta iteración
            }

            $costo = $esFactura ? $pre->costosiva : $pre->costociva;
            // 🔹 Seleccionar el costo correcto según el tipo de factura
            $t->price = $costo;

            // 🔹 Calcular el total si newcosto es NULL
            if ($t->newcosto == 0.00) {

                $t->total =  $costo * $t->quantity;
            }

            $t->save();
        }
        $this->cargaData(); // Recargar datos después de la actualización
    }

    public function obtenerProductos()
    {
        return;
    }

    function ajustarDecimal($numero, $decimales = 2)
    {
        $factor = pow(10, $decimales);
        $numero *= $factor;

        $entero = floor($numero);
        $decimal = $numero - $entero;

        // Solo redondea si el decimal es > 0.5 (estrictamente mayor)
        if ($decimal > 0.5) {
            $entero++;
        }

        // Devuelve el resultado como float
        return $entero / $factor;
    }
}
