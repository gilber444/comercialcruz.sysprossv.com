<?php

namespace App\Console\Commands;

use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Throwable;

// [2026-03-31] Sync de metas VPS → local
// Trae: metas_globales, metas_sucursales (filtrada por sucursal), metas_roles,
//       metas_empleados, metas_dias del mes actual y anterior
// Los IDs del VPS se respetan en local (upsert por id)
class SyncMetasDesdeVPS extends Command
{
    protected $signature = 'sync:metas
        {--mes=     : Mes a sincronizar (1-12). Por defecto: mes actual}
        {--anio=    : Año a sincronizar. Por defecto: año actual}
        {--sucursal=: ID de sucursal. Por defecto: APP_SUCURSAL_ID del .env}
        {--all      : Sincronizar mes actual + mes anterior}';

    protected $description = 'Sincroniza configuración de metas desde VPS hacia local (globales→sucursales→roles→empleados→dias)';

    protected string $connRemote = 'vpsmysql';
    protected string $connLocal  = 'localmysql';

    public function handle()
    {
        if (env('APP_MODO', 'local') === 'vps') {
            $this->error('❌ sync:metas NO debe ejecutarse en VPS. Abortando.');
            return self::FAILURE;
        }

        // ── Validar conexiones ────────────────────────────────────────────
        try {
            DB::connection($this->connRemote)->getPdo();
            DB::connection($this->connLocal)->getPdo();
        } catch (Throwable $e) {
            $this->error('❌ Conexión fallida: ' . $e->getMessage());
            return self::FAILURE;
        }

        // ── Resolver sucursal ─────────────────────────────────────────────
        $sucursalId = $this->option('sucursal')
            ?: env('APP_SUCURSAL_ID', env('SUCURSAL_ID', null));

        if (!$sucursalId) {
            $this->error('❌ No se definió sucursal. Usa --sucursal=X o define APP_SUCURSAL_ID en .env');
            return self::FAILURE;
        }
        $sucursalId = (int) $sucursalId;

        // ── Resolver meses a sincronizar ──────────────────────────────────
        $periodos = [];

        if ($this->option('all')) {
            $periodos[] = ['mes' => Carbon::now()->month,              'anio' => Carbon::now()->year];
            $periodos[] = ['mes' => Carbon::now()->subMonth()->month,  'anio' => Carbon::now()->subMonth()->year];
        } else {
            $periodos[] = [
                'mes'  => (int) ($this->option('mes')  ?: Carbon::now()->month),
                'anio' => (int) ($this->option('anio') ?: Carbon::now()->year),
            ];
        }

        $this->info('== INICIO SYNC METAS VPS → LOCAL == ' . now()->toDateTimeString());
        $this->line("Sucursal: #{$sucursalId}");

        foreach ($periodos as $periodo) {
            $this->syncPeriodo($sucursalId, $periodo['mes'], $periodo['anio']);
        }

        $this->info('== FIN SYNC METAS == ' . now()->toDateTimeString());
        return self::SUCCESS;
    }

    protected function syncPeriodo(int $sucursalId, int $mes, int $anio): void
    {
        $this->line("─── Periodo {$mes}/{$anio} ───");

        // ── 1. metas_globales ─────────────────────────────────────────────
        $global = DB::connection($this->connRemote)
            ->table('metas_globales')
            ->where('mes', $mes)
            ->where('anio', $anio)
            ->first();

        if (!$global) {
            $this->warn("  ⚠ No existe meta global para {$mes}/{$anio} en VPS. Saltando.");
            return;
        }

        // Si existe un global con mismo (mes, anio) pero diferente id → eliminar antes
        $localGlobal = DB::connection($this->connLocal)->table('metas_globales')
            ->where('mes', $global->mes)
            ->where('anio', $global->anio)
            ->first();

        if ($localGlobal && $localGlobal->id !== $global->id) {
            DB::connection($this->connLocal)->table('metas_globales')
                ->where('id', $localGlobal->id)
                ->delete();
            $this->warn("  ⚠ metas_globales local id={$localGlobal->id} eliminada (conflicto con VPS id={$global->id})");
        }

        // [2026-03-31] upsert por id — respeta el ID del VPS en local
        DB::connection($this->connLocal)->table('metas_globales')->upsert(
            [[
                'id'           => $global->id,
                'mes'          => $global->mes,
                'anio'         => $global->anio,
                'monto_global' => $global->monto_global,
                'estado'       => $global->estado,
                'creado_por'   => $global->creado_por,
                'created_at'   => $global->created_at,
                'updated_at'   => $global->updated_at,
            ]],
            ['id'],
            ['monto_global', 'estado', 'updated_at']
        );
        $this->line("  ✓ metas_globales id={$global->id} ({$global->estado})");

        // ── 2. metas_sucursales (solo la de esta sucursal) ────────────────
        $sucursal = DB::connection($this->connRemote)
            ->table('metas_sucursales')
            ->where('meta_global_id', $global->id)
            ->where('sucursal', $sucursalId)
            ->first();

        if (!$sucursal) {
            $this->warn("  ⚠ No existe meta_sucursal para sucursal #{$sucursalId} en {$mes}/{$anio}. Saltando.");
            return;
        }

        // Si existe una fila con mismo (meta_global_id, sucursal) pero diferente id
        // el upsert por 'id' actualizaría esa fila en vez de insertar el id correcto.
        // Solución: borrar la fila conflictiva primero, luego hacer upsert por id.
        $localSuc = DB::connection($this->connLocal)->table('metas_sucursales')
            ->where('meta_global_id', $sucursal->meta_global_id)
            ->where('sucursal', $sucursal->sucursal)
            ->first();

        if ($localSuc && $localSuc->id !== $sucursal->id) {
            // Fila con id diferente — la borramos (CASCADE elimina sus roles/empleados/días)
            DB::connection($this->connLocal)->table('metas_sucursales')
                ->where('id', $localSuc->id)
                ->delete();
            $this->warn("  ⚠ metas_sucursales local id={$localSuc->id} eliminada (conflicto con VPS id={$sucursal->id})");
        }

        DB::connection($this->connLocal)->table('metas_sucursales')->upsert(
            [[
                'id'              => $sucursal->id,
                'meta_global_id'  => $sucursal->meta_global_id,
                'sucursal'        => $sucursal->sucursal,
                'porcentaje'      => $sucursal->porcentaje,
                'monto_calculado' => $sucursal->monto_calculado,
                'monto_ajustado'  => $sucursal->monto_ajustado,
                'ajuste_manual'   => $sucursal->ajuste_manual,
                'created_at'      => $sucursal->created_at,
                'updated_at'      => $sucursal->updated_at,
            ]],
            ['id'],
            ['porcentaje', 'monto_calculado', 'monto_ajustado', 'ajuste_manual', 'updated_at']
        );
        $this->line("  ✓ metas_sucursales id={$sucursal->id}");

        // ── 3. metas_roles ────────────────────────────────────────────────
        $roles = DB::connection($this->connRemote)
            ->table('metas_roles')
            ->where('meta_sucursal_id', $sucursal->id)
            ->get();

        if ($roles->isEmpty()) {
            $this->warn("  ⚠ No hay metas_roles para sucursal #{$sucursalId}.");
            return;
        }

        foreach ($roles as $rol) {
            DB::connection($this->connLocal)->table('metas_roles')->upsert(
                [[
                    'id'               => $rol->id,
                    'meta_sucursal_id' => $rol->meta_sucursal_id,
                    'rol'              => $rol->rol,
                    'porcentaje'       => $rol->porcentaje,
                    'monto_calculado'  => $rol->monto_calculado,
                    'created_at'       => $rol->created_at,
                    'updated_at'       => $rol->updated_at,
                ]],
                ['id'],
                ['porcentaje', 'monto_calculado', 'updated_at']
            );
        }
        $this->line("  ✓ metas_roles ({$roles->count()} roles)");

        $rolIds = $roles->pluck('id')->toArray();

        // ── 4. metas_empleados ────────────────────────────────────────────
        $empleados = DB::connection($this->connRemote)
            ->table('metas_empleados')
            ->whereIn('meta_rol_id', $rolIds)
            ->get();

        if ($empleados->isEmpty()) {
            $this->warn("  ⚠ No hay metas_empleados para sucursal #{$sucursalId}.");
            return;
        }

        foreach ($empleados as $emp) {
            DB::connection($this->connLocal)->table('metas_empleados')->upsert(
                [[
                    'id'            => $emp->id,
                    'meta_rol_id'   => $emp->meta_rol_id,
                    'user_id'       => $emp->user_id,
                    'meta_mensual'  => $emp->meta_mensual,
                    'quincena_1'    => $emp->quincena_1,
                    'quincena_2'    => $emp->quincena_2,
                    'diaria_base'   => $emp->diaria_base,
                    'created_at'    => $emp->created_at,
                    'updated_at'    => $emp->updated_at,
                ]],
                ['id'],
                ['meta_mensual', 'quincena_1', 'quincena_2', 'diaria_base', 'updated_at']
            );
        }
        $this->line("  ✓ metas_empleados ({$empleados->count()} empleados)");

        $empIds = $empleados->pluck('id')->toArray();

        // ── 5. metas_dias ─────────────────────────────────────────────────
        // Solo días del mes del periodo
        $inicioMes = Carbon::create($anio, $mes, 1)->format('Y-m-d');
        $finMes    = Carbon::create($anio, $mes, 1)->endOfMonth()->format('Y-m-d');

        $dias = DB::connection($this->connRemote)
            ->table('metas_dias')
            ->whereIn('meta_empleado_id', $empIds)
            ->whereBetween('fecha', [$inicioMes, $finMes])
            ->get();

        $insertados = 0;
        foreach ($dias->chunk(500) as $chunk) {
            $rows = $chunk->map(fn($d) => [
                'id'               => $d->id,
                'meta_empleado_id' => $d->meta_empleado_id,
                'fecha'            => $d->fecha,
                'meta_dia'         => $d->meta_dia,
                'meta_dia_ajustada'=> $d->meta_dia_ajustada,
                'bloqueado'        => $d->bloqueado,
                'created_at'       => $d->created_at,
                'updated_at'       => $d->updated_at,
            ])->toArray();

            DB::connection($this->connLocal)->table('metas_dias')->upsert(
                $rows,
                ['id'],
                ['meta_dia', 'meta_dia_ajustada', 'bloqueado', 'updated_at']
            );
            $insertados += count($rows);
        }
        $this->line("  ✓ metas_dias ({$insertados} días, {$inicioMes} → {$finMes})");

        // ── Limpiar caché del dashboard ───────────────────────────────────
        \Illuminate\Support\Facades\Cache::forget("schema_metas_dias");
        \Illuminate\Support\Facades\Cache::forget("gerente_meta_suc_{$sucursalId}_{$anio}_{$mes}");
        \Illuminate\Support\Facades\Cache::forget("gerente_metas_dias_{$sucursalId}_{$anio}_{$mes}_" . Carbon::now()->format('Y-m-d'));
        \Illuminate\Support\Facades\Cache::forget("gerente_metas_emp_{$sucursalId}_{$anio}_{$mes}");
        $this->line("  ✓ Caché dashboard limpiado");
    }
}
