<div class="row p-1">
    <div class="table-responsive text-nowrap">
        <table class="table table-hover table-sm">
            <thead>
                <th class="text-center">CODIGO</th>
                <th class="text-center">DESCRIPCION</th>
                <th class="text-center">MEDIDA</th>
                <th class="text-right">P.U.</th>
                <th class="text-center">CANTIDAD</th>
                {{-- <th class="text-center">FECHA VEN.</th> --}}
                <th class="text-center">TOTAL</th>
                <th class="text-center"></th>
            </thead>
            <tbody>

                @forelse ( $car as $item)
                    <tr>
                        <td class="text-center">
                            <h6>{{ $item->RProductos->codebar3 }}</h6>
                        </td>
                        <td>{{ $item->RProductos->nombreProducto }}</td>
                        <td>{{ $item->RProductos->Rmedidas->unidad }}</td>
                        <td class="text-end" width='200%'>
                            <input type="text" class="form-control w-100" style="min-width: 80px;" placeholder="{{$item->costo}}" wire:model='pri.{{$item->id}}' wire:keydown.enter="updatePre({{$item->id}})" wire:change="updatePre({{$item->id}})" value="{{ number_format($item->costo, 2) }}">

                        </td>
                        <td class="text-center" width='25%'>
                            <input type="text" class="form-control w-100" style="min-width: 80px;" placeholder="{{ $item->cantidad }}"
                                wire:model.lazy="can.{{ $item->id }}"
                                wire:keydown.enter="updateQty({{ $item->id }})"
                                wire:change="updateQty({{ $item->id }})" value="{{ $item->cantidad }}">{{ $item->cantidad }}

                        </td>
                        {{-- <td class="text-center">{{ $item->fechaVencimiento}}</td> --}}
                        <td class="text-end">$ {{ number_format($item->total, 2) }}</td>
                        <td class="text-center">
                            <a class="btn btn-danger btn-sm" href="javascript:void(0);"
                                onclick="Confirm2('{{ $item->id }}')"><i class="bx bx-trash"></i></a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
