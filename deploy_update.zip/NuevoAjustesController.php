<?php

namespace App\Http\Livewire;

use App\Models\Actividades;
use App\Models\Ajustes;
use App\Models\AjustesDetalles;
use App\Models\Inventarios;
use App\Models\Kardex;
use App\Models\Precios;
use App\Models\Productos;
use App\Models\Sucursales;
use App\Models\tmpAjuste;
use App\Traits\GenerarJsonAjuste;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class NuevoAjustesController extends Component
{
    use GenerarJsonAjuste;

    public $pageTitle, $componentName;

    public $total, $itemsQuantity, $can = [], $pri = [], $uni = [], $cart = [], $existenciaActual = [], $existenciaAjustada = [];

    public $productos, $sucursal, $producto, $sucursalOrigen, $cantidad, $fecha, $detalle, $movimiento, $status, $tipo, $search, $selected_id, $select_id;


    public function mount()
    {
        $this->pageTitle   = 'Nuevo';
        $this->componentName = 'Ajuste';
        $this->fecha = date('Y-m-d');

        $acti = Actividades::where('user', Auth::id())
            ->whereDate('created_at', Carbon::today())
            ->where('status', 'Activo')
            ->first();

        if ($acti) {
            $this->sucursal = $acti->sucursal;
            $this->tipo     = 'Ingreso';
        }

        $this->Carrito();
    }

    public function Carrito()
    {
        $ca = tmpAjuste::where('usuario', Auth::id())->get();

        foreach ($ca as $c) {
            $this->uni[$c->id] = $c->unidad;
            $this->pri[$c->id] = $c->price;
            $this->can[$c->id] = $c->quantity;

            if ($this->sucursal) {
                $inventario = Inventarios::where('producto', $c->producto)
                    ->where('sucursal', $this->sucursal)
                    ->first();
                $existencia = $inventario->existencia ?? 0;
            } else {
                $existencia = 0;
            }

            $this->existenciaActual[$c->id] = $existencia;

            if ($this->tipo == 'Ingreso') {
                $this->existenciaAjustada[$c->id] = $c->ingreso + $existencia;
            } else {
                $this->existenciaAjustada[$c->id] = $existencia - $c->ingreso;
            }
        }

        $this->total         = tmpAjuste::where('usuario', Auth::id())->sum('total');
        $this->itemsQuantity = tmpAjuste::where('usuario', Auth::id())->count();
    }

    public function paginationView()
    {
        return 'vendor.livewire.bootstrap';
    }

    public function render()
    {
        $this->cart = tmpAjuste::where('usuario', Auth::id())->orderBy('id', 'desc')->get();

        return view('livewire.ajustes.nuevo-ajuste', ['sucursales' => Sucursales::all()])
            ->extends('layouts.theme.app')
            ->section('content');
    }

    protected $listeners = [
        'scan-code'      => 'ScanCode',
        'removeItem'     => 'removeItem',
        'clearCart'      => 'clearCart',
        'Store'          => 'Store',
        'scan-code-byid' => 'ScanCodeById',
        'print-ticket'   => 'printTicket',
    ];

    public function ScanCodeById($id)
    {
        $this->increaseQty($id);
    }

    public function increaseQty($productId)
    {
        $product = Precios::with('Rproductos:id,nombreProducto')->find($productId);

        if ($product) {
            $tmp = tmpAjuste::create([
                'producto'   => $product->producto,
                'name'       => $product->Rproductos->nombreProducto,
                'price'      => $product->costosiva,
                'quantity'   => 1,
                'sucursal'   => null,
                'codebar'    => $product->codebar,
                'unidad'     => $product->medida,
                'medida'     => $product->presentacion,
                'total'      => $product->costosiva,
                'limit'      => $product->cantidad,
                'ingreso'    => $product->cantidad,
                'inventario' => null,
                'usuario'    => Auth::id(),
            ]);
            $this->Carrito();
            $this->emit('focus-input', ['id' => $tmp->id]);
        } else {
            $this->emit('item-error', 'Producto no encontrado');
        }
    }

    public function updateUni($id)
    {
        $uniNew = $this->uni[$id];
        $tmp    = tmpAjuste::find($id);
        $PreCan = Precios::where('producto', $tmp->producto)->where('medida', $uniNew)->first();

        $tmp->unidad  = $uniNew;
        $tmp->limit   = $PreCan->cantidad;
        $tmp->price   = $PreCan->costosiva;
        $tmp->ingreso = $tmp->quantity * $PreCan->cantidad;
        $tmp->total   = $PreCan->costosiva * $tmp->quantity;
        $tmp->save();

        $this->Carrito();
    }

    public function updateQty($id)
    {
        $tmp           = tmpAjuste::find($id);
        $tmp->quantity = $this->can[$id];
        $tmp->ingreso  = $tmp->quantity * $tmp->limit;
        $tmp->total    = $tmp->price * $tmp->quantity;
        $tmp->save();

        $this->Carrito();
    }

    public function ScanCode($barcode, $cant = 1)
    {
        $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
            ->join('inventarios as i', 'i.producto', 'productos.id')
            ->where('p.codebar', 'like', '%' . $barcode . '%')
            ->select(
                'productos.id', 'productos.nombreProducto', 'i.existencia',
                'p.codebar', 'i.id as inventario', 'p.costosiva', 'p.cantidad',
                'i.sucursal', 'p.presentacion', 'p.medida', 'p.id as precio'
            )
            ->first();

        if ($product) {
            tmpAjuste::create([
                'producto'   => $product->id,
                'name'       => $product->nombreProducto,
                'price'      => $product->costosiva,
                'quantity'   => $cant,
                'sucursal'   => null,
                'codebar'    => $product->codebar,
                'unidad'     => $product->medida,
                'medida'     => $product->presentacion,
                'total'      => $cant * $product->costosiva,
                'limit'      => $product->cantidad,
                'ingreso'    => $cant * $product->cantidad,
                'inventario' => null,
                'usuario'    => Auth::id(),
            ]);
            $this->Carrito();
        } else {
            $this->emit('item-error', 'El producto no esta registrado');
        }
    }

    public function InCart($productId)
    {
        return tmpAjuste::where('usuario', Auth::id())
            ->where('producto', $productId)
            ->exists();
    }

    public function removeItem($productId)
    {
        tmpAjuste::find($productId)?->delete();
        $this->Carrito();
    }

    public function clearCart()
    {
        tmpAjuste::where('usuario', Auth::id())->delete();
        $this->Carrito();
    }

    public function Store()
    {
        $this->validate([
            'sucursal' => 'required',
            'tipo'     => 'required|in:Ingreso,Egreso',
            'fecha'    => 'required',
            'detalle'  => 'required',
        ], [
            'sucursal.required' => 'La sucursal es requerida',
            'tipo.required'     => 'El tipo de ajuste es requerido',
            'tipo.in'           => 'El tipo de ajuste debe ser Ingreso o Egreso',
            'fecha.required'    => 'La fecha del ingreso es requerida',
            'detalle.required'  => 'El detalle del ingreso es requerido',
        ]);

        $items = tmpAjuste::where('usuario', Auth::id())->get();

        if ($items->isEmpty()) {
            $this->emit('item-error', 'No hay productos para procesar.');
            return;
        }

        $user       = Auth::user();
        $tipo       = ($this->tipo === 'Ingreso') ? 'Ingreso' : 'Egreso';
        $autoAproba = $user->can('AjusteAutoAproba_Direct');

        try {
            DB::beginTransaction();

            $ajuste = Ajustes::create([
                'sucursal' => $this->sucursal,
                'fecha'    => $this->fecha,
                'detalle'  => $this->detalle,
                'status'   => 'Ingresado',
                'tipo'     => $tipo,
                'user'     => $user->id,
            ]);

            $productoIds = $items->pluck('producto')->unique()->values();
            $inventarios = Inventarios::whereIn('producto', $productoIds)
                ->where('sucursal', $this->sucursal)
                ->get()
                ->keyBy('producto');

            foreach ($items as $item) {
                $inv = $inventarios->get($item->producto);

                if (!$inv) {
                    throw new \RuntimeException("No existe inventario para el producto {$item->producto}");
                }

                AjustesDetalles::create([
                    'ajuste'     => $ajuste->id,
                    'producto'   => $item->producto,
                    'inventario' => $inv->id,
                    'medida'     => $item->unidad,
                    'cantidad'   => $item->quantity,
                    'ingreso'    => $item->ingreso,
                    'costo'      => $item->price,
                    'total'      => $item->price * $item->quantity,
                ]);
            }

            // Perfiles con autoridad propia: aplicar inventario y kardex de inmediato
            if ($autoAproba) {
                $this->aplicarAjuste($ajuste);
                $ajuste->status         = 'Finalizado';
                $ajuste->autorizado_por = $user->id;
                $ajuste->save();
            }

            DB::commit();

            $this->clearCart();
            $this->resetUI();

            if ($autoAproba) {
                $this->emit('print-ticket2', $this->GenerarJsonAjuste($ajuste->id));
                $this->emit('item-added', 'Ajuste aplicado directamente.');
            } else {
                $this->emit('item-added', 'Ajuste registrado - Pendiente de aprobar');
            }

        } catch (\Exception $e) {
            DB::rollBack();
            $this->emit('item-error', 'Error al registrar el ajuste: ' . $e->getMessage());
        }
    }

    /**
     * Aplica inventario y kardex para cada detalle del ajuste.
     * Se llama dentro de la transacción activa de Store().
     */
    private function aplicarAjuste(Ajustes $ajuste): void
    {
        $sucursal = Sucursales::find($ajuste->sucursal);

        // Sucursal local: el sync se encarga del kardex e inventario
        if ($sucursal && $sucursal->modo === 'local') {
            return;
        }

        $detalles = AjustesDetalles::where('ajuste', $ajuste->id)->get();

        foreach ($detalles as $item) {
            $existencia = Inventarios::where('producto', $item->producto)
                ->where('sucursal', $ajuste->sucursal)
                ->lockForUpdate()
                ->first();

            if (!$existencia) continue;

            $ultiR = Kardex::where('producto', $item->producto)
                ->where('inventario', $existencia->id)
                ->lockForUpdate()
                ->latest()
                ->first();

            if ($ajuste->tipo === 'Ingreso') {
                $nuevaExistencia = $existencia->existencia + $item->ingreso;
                $saldoValor      = $ultiR ? $ultiR->saldoValor + $item->total : $item->total;

                Kardex::create([
                    'producto'        => $item->producto,
                    'inventario'      => $existencia->id,
                    'descripcion'     => 'Ingreso por Ajuste #' . $ajuste->id . ' ' . $ajuste->detalle . ', aplicado por ' . Auth::user()->name,
                    'fecha'           => date('Y-m-d'),
                    'hora'            => date('H:i:s'),
                    'ingresoCantidad' => $item->ingreso,
                    'ingresoValor'    => $item->total,
                    'egresoCantidad'  => 0,
                    'egresoValor'     => 0,
                    'saldoCantidad'   => $nuevaExistencia,
                    'saldoValor'      => $saldoValor,
                    'user'            => Auth::id(),
                ]);
            } else {
                $nuevaExistencia = max(0, $existencia->existencia - $item->ingreso);
                $saldoValor      = $ultiR ? max(0, $ultiR->saldoValor - $item->total) : 0;

                Kardex::create([
                    'producto'        => $item->producto,
                    'inventario'      => $existencia->id,
                    'descripcion'     => 'Egreso por Ajuste #' . $ajuste->id . ' ' . $ajuste->detalle . ', aplicado por ' . Auth::user()->name,
                    'fecha'           => date('Y-m-d'),
                    'hora'            => date('H:i:s'),
                    'ingresoCantidad' => 0,
                    'ingresoValor'    => 0,
                    'egresoCantidad'  => $item->ingreso,
                    'egresoValor'     => $item->total,
                    'saldoCantidad'   => $nuevaExistencia,
                    'saldoValor'      => $saldoValor,
                    'user'            => Auth::id(),
                ]);
            }

            $existencia->existencia = $nuevaExistencia;
            $existencia->save();
        }
    }

    public function resetUI()
    {
        $this->sucursalOrigen = 'Elegir sucursal';
        $this->detalle        = '';
    }

    public function cargaSucursal()
    {
        $this->emitTo('modal-ajuste', 'updateSucursal', $this->sucursal);
    }
}
