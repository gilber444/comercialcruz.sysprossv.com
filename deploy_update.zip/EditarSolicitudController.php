<?php

namespace App\Http\Livewire;

use App\Models\Inventarios;
use App\Models\Kardex;
use App\Models\Productos;
use App\Models\Solicitudes;
use App\Models\SolicitudesDetalles;
use App\Models\Sucursales;
use App\Models\tmpSolicitudes;
use Exception;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Livewire\Component;
use Livewire\WithPagination;

class EditarSolicitudController extends Component
{
    use WithPagination;

    public  $origen, $origen1, $destino, $destino1, $search, $selected_id, $correlativo, $fecha, $detalle, $itemsQuantity, $total, $can = [], $empre, $sucu, $ca, $rol, $cart=[], $solicitudes;
    private $pagination = 7;

    public function mount($id)
    {
        $this->selected_id = $id;
        $user = Auth::user();
        $this->rol = $user->profile;
        $bus = Solicitudes::find($this->selected_id);
        $this->origen = $bus->origen;
        $this->destino = $bus->destino;
        $this->correlativo = $bus->numero;
        $this->fecha = $bus->fecha;
        $this->detalle = $bus->detalle;

        $this->fecha = date('Y-m-d H:i:s');

        $items = Productos::orderBy('id'); // Reemplaza esto con tu lógica para obtener los ítems

        foreach ($items as $item) {
            $this->can[$item->id] = null;
        }
        $user = Auth::user();

        if ($user->profile === 'Super' || $user->profile === 'Administrador' || $user->profile === 'Auditor')
        {
            $this->origen1 = Sucursales::with('Rempresa')->orderBy('nombre')->get();
            $this->destino1 = Sucursales::with('Rempresa')->OrderBy('nombre')->get();
        }
        else
        {
            $this->origen1 = Sucursales::with('Rempresa')->find($user->sucursal);
            $this->destino1 = Sucursales::with('Rempresa')->OrderBy('nombre')->get();
            //$this->destino = $this->destino1->id;
            $this->origen = $this->origen1->id;

        }

        $this->empre = $user->empresa;
        $this->sucu = $user->sucursal;

        $this->Carrito();

    }

    public function Carrito()
    {
        $user = Auth::user();
        $this->solicitudes = SolicitudesDetalles::where('solicitud', $this->selected_id)->get();
        $this->cart =  tmpSolicitudes::where('user', $user->id)->orderBy('id', 'desc')->get();
        $this->total = tmpSolicitudes::where('user', $user->id)->get()->sum('cantidad');
        $t = tmpSolicitudes::where('user', $user->id)->get()->sum('cantidad');
        $s = SolicitudesDetalles::where('solicitud', $this->selected_id)->get()->sum('cantidad');
         $this->itemsQuantity = $t + $s;
        foreach($this->cart as $item)
        {
            $this->can[$item->id] = $item->cantidad;
        }

    }

    public function paginationView()
    {
        return 'vendor.livewire.bootstrap';
    }

    public function render()
    {
        $user = Auth::user();

        return view('livewire.existencias.editar-solicitud')
        ->extends('layouts.theme.app')
        ->section('content');
    }

    protected $listeners = [
        'scan-code' => 'ScanCode',
        'removeItem' => 'removeItem',
        'clearCart' => 'clearCart',
        'deleteRoww' => 'DestroyProd',
        'Store' => 'Store',
        'scan-code-byid' => 'ScanCodeById',
        'print-ticket' => 'printTicket',
    ];



    public function ScanCodeById(Productos $product)
    {
        $this->increaseQty($product->id);
    }

    public function ScanCode($barcode, $cant = 1)
    {
        $user = Auth::user();
        $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
        ->join('inventarios as i', 'i.producto', 'productos.id')
        ->where('p.codebar', $barcode)
        ->where('i.sucursal', $user->sucursal)
        ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'p.cantidad', 'i.sucursal', 'p.presentacion')
        ->first();

        if($product == null)
        {
            $this->emit('scan-notfound', 'El producto no esta registrado');
        }
        else
        {
            if($this->InCart($product->id))
            {
                $this->increaseQty($product->id);
                return;
            }

            $tmp = tmpSolicitudes::create([
                'codebar' => $product->codebar,
                'producto' => $product->id,
                'name' => $product->nombreProducto,
                'cantidad' => $cant,
                'costo' => $product->costosiva,
                'unidad' => $product->medida,
                'medida' => $product->presentacion,
                'limit' => $product->cantidad,
                'descargar' => $cant * $product->cantidad,
                'user' => $user->id
            ]);
            $this->Carrito();
        }
    }

    public function InCart($productId)
    {
        $user_id = Auth::user()->id;

        $exist = tmpSolicitudes::where('producto', $productId)->where('user', $user_id)->first();
        if($exist)
            return true;
        else
            return false;
    }

    public function increaseQty($productId, $cant = 1)
    {
        $user = Auth::user();

        $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
            ->join('inventarios as i', 'i.producto', 'productos.id')
            ->where('p.producto', $productId)
            ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'p.cantidad', 'i.sucursal', 'p.presentacion')
            ->first();


        $exist = tmpSolicitudes::where('producto', $productId)->where('user', $user->id)->first();

        if($exist)
        {
            $exist->cantidad =  $exist->cantidad + $cant;
            $exist->descargar = $exist->cantidad * $product->cantidad;
            $exist->save();
        }
        else
        {
            $tmp = tmpSolicitudes::create([
                'codebar' => $product->codebar,
                'producto' => $product->id,
                'name' => $product->nombreProducto,
                'cantidad' => $cant,
                'costo' => $product->costosiva,
                'unidad' => $product->medida,
                'medida' => $product->presentacion,
                'limit' => $product->cantidad,
                'descargar' => $cant * $product->cantidad,
                'user' => $user->id
            ]);
        }

        $this->Carrito();

    }

    public function updateQty($id)
    {
        $user = Auth::user();

        $cantidades = $this->can[$id];

        $exist = tmpSolicitudes::find($id);

        $exist->cantidad =  $cantidades;
        $exist->descargar = $cantidades * $exist->limit;
        $exist->save();

        $this->Carrito();
    }

    public function removeItem($id)
    {
        $delete = tmpSolicitudes::find($id)->delete();
        $this->Carrito();
    }

    public function DestroyProd(SolicitudesDetalles $detalle)
    {
        $up = SOlicitudes::find($detalle->solicitud);
        $exis = Inventarios::where('producto', $detalle->producto)->where('sucursal', $up->origen)->first();

        $nuevo = $exis->existencia + $detalle->ingreso;

        $exis->existencia = $nuevo;
        $exis->save();

        $kar = Kardex::where('producto', $detalle->producto)->where('inventario', $exis->id)->latest('id')->first();
        $kard = Kardex::create([
            'producto' => $detalle->producto,
            'inventario' => $exis->id,
            'descripcion' => 'Eliminacion del producto de la solicitud ' . $kar->descripcion,
            'fecha' => date('Y-m-d'),
            'hora' => date('H:i:s'),
            'ingresoCantidad' => $detalle->cantidad,
            'ingresoValor' => $detalle->total,
            'egresoCantidad' => 0.00,
            'egresoValor' => 0.00,
            'saldoCantidad' => $nuevo,
            'saldoValor' => $kar->saldoValor - $detalle->total
        ]);

        //dd($kar);
        $detalle->delete();
        $this->Carrito();
        $this->emit('item-deleted', 'Producto Eliminado de la solicitud');
    }

    public function clearCart()
    {
        $user_id = Auth::user()->id;
        $delete = tmpSolicitudes::where('user', $user_id)->delete();
        $this->Carrito();
    }

    public function Update()
    {
        $rules = [
            'destino' => 'required',
            'fecha' => 'required'
        ];

        $messages = [
            'destino.required' => 'Seleccione el destino de solicutd',
            'fecha.required' => 'la fecha es requerido'
        ];

        $this->validate($rules, $messages);

        $user = Auth::user();

        DB::beginTransaction();

        try
        {
            $soli = Solicitudes::find($this->selected_id);
            $soli->detalle = $this->detalle;
            $soli->origen = $this->origen;
            $soli->destino = $this->destino;
            $soli->fecha = $this->fecha;
            $soli->save();

            if($soli)
            {
                $items = tmpSolicitudes::where('user', $user->id)->get();
                foreach($items as $item)
                {
                    SolicitudesDetalles::create([
                        'solicitud' => $this->selected_id,
                        'producto' => $item->producto,
                        'origen' => $this->origen,
                        'destino' => $this->destino,
                        'cantidad' => $item->cantidad,
                        'costo' => $item->costo,
                        'total' => $item->cantidad * $item->costo,
                        'realizado' => $user->id,
                        'autorizado' => $user->id,
                        'despachado' => $user->id,
                        'ingresado' => $user->id,
                        'estado' => 'Despachado',
                        //'sucursal' => $user->sucursal,
                        //'empresa' => $user->empresa,
                    ]);

                    $inven = Inventarios::where('sucursal', $this->origen)->where('producto', $item->producto)->first();

                    $newExis = $inven->existencia - $item->cantidad;

                    $inven->existencia = $newExis;
                    $inven->save();

                    $kardex = Kardex::where('producto', $item->producto)->where('inventario', $inven->id)
                        ->orderBy('id', 'desc')
                        ->first();

                    //$saldoCantidad = $kardex->saldoCantidad - $detalle->cantidad;
                    //$saldoValor = $saldoCantidad * $detalle->costo;
                    $sucur = Sucursales::find($this->origen);
                    $des = Sucursales::find($this->destino);
                    $kar = Kardex::create([
                        'producto' => $item->producto,
                        'inventario' => $inven->id,
                        'descripcion' => 'Despacho de producto de la sucursal ' . $sucur->nombre . ' para la sucursal ' . $des->nombre,
                        'fecha' => date('Y-m-d'),
                        'hora' => date('H:i:s'),
                        'ingresoCantidad' => 0,
                        'ingresoValor' => 0,
                        'egresoCantidad' => $item->cantidad,
                        'egresoValor' => $item->cantidad * $item->costo,
                        'saldoCantidad' => $newExis,
                        'saldoValor' => ($newExis * $item->costo),
                    ]);

                }
            }

            DB::commit();

            $this->clearCart();
            $this->emit('item-added', 'Solicitud Registrada, pendiente de Autizacion');
            $this->resetUI();
            return Redirect::to('/solicitudesVer');
        }
        catch(Exception $e)
        {
            DB::rollback();
            $this->emit('scan-notfound', $e->getMessage());
        }
    }

    public function resetUI()
    {
        $this->origen = '';
        $this->selected_id = '';
        $this->destino = '';
        $this->destino1 = '';
        $this->search = '';
        $this->correlativo = '';
        $this->fecha = '';
        $this->detalle = '';
        $this->itemsQuantity = '';
        $this->total = '';
        $this->can = [];
        $this->empre = '';
        $this->sucu = '';
        $this->ca = '';
        //$this->rol = '';
        $this->selected_id = 0;
        $this->resetValidation();
        $this->resetPage();
    }
}
