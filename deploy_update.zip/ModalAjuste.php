<?php

namespace App\Http\Livewire;

use App\Models\Inventarios;
use App\Models\Precios;
use App\Models\Productos;
use Livewire\Component;

class ModalAjuste extends Component
{
    public $search, $products = [], $sucursal;

    public function liveSearch()
    {
        if(strlen($this->search) > 0)
        {
            $this->products = Precios::with([
                'Rproductos:id,nombreProducto'
            ])
            ->where('cantidad', 1)
            ->whereNull('deleted_at') // evita precios eliminados
            ->whereHas('Rproductos', function ($query) {
                $query->whereNull('productos.deleted_at') //  nuevo: evita productos soft-deleted
                          ->where('productos.activo', 1)       //  nuevo: solo productos activos
              //  $query->where('activo', 1) // Solo productos activos
                      ->where(function ($q) {
                          $q->where('nombreProducto', 'like', '%' . $this->search . '%')
                            ->orWhere('codebar', 'like', '%' . $this->search . '%'); // Permite búsqueda por código de barras
                      });
            })
            ->selectRaw('MIN(id) as id, producto, cantidad, costosiva,  codebar, presentacion')
            ->groupBy('producto', 'cantidad', 'costosiva', 'codebar', 'presentacion')
            ->take(50)
            ->get();
        }
        else
        {
            $this->products = [];
        }
    }

    public function render()
    {
        $this->liveSearch();
        return view('livewire.ajustes.modal-ajuste');
    }

    public function Add($id)
    {
        //dd($id);
        $this->emit('scan-code-byid', $id);
        $this->search = '';
    }

    protected $listeners = ['updateSucursal' => 'setSucursal'];

    public function setSucursal($sucursal)
    {
        $this->sucursal = $sucursal;
    }
}
