@php
    use Illuminate\Support\Facades\DB;
    use Carbon\Carbon;
@endphp
<div wire:ignore.self class="modal fade" id="modalSearchProduct" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <div class="input-group input-group-merge">
                    <span class="input-group-text">
                        <i class="fas fa-search"></i>
                    </span>
                    <input type="text" wire:model="search" id="modal-search-input" wire:click="liveSearch()"
                        placeholder="Buscar por nombre, código de barras o categorías" class="form-control">
                </div>
            </div>
            <div class="modal-body">
                <div class="row p-2">
                    <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                        <table class="table table-hover table-sm">
                            <thead>
                                <th class="text-center">CÓDIGO BARRA</th>
                                <th class="text-center">DESCRIPCIÓN</th>
                                <th class="text-center">MEDIDA</th>
                                <th class="text-center">CANTIDAD</th>
                                <th class="text-center">EXISTENCIA</th>
                                <th class="text-center"></th>
                            </thead>
                            <tbody>
                                @forelse ($products as $product)
                                    <tr class="product-row" data-product-id="{{ $product->id }}" tabindex="-1">
                                        <td class="text-center"><h6>{{ $product->codebar3 }}</h6></td>
                                        <td style="cursor: pointer"><h6><b>{{ $product->nombreProducto }}</b></h6></td>
                                        <td class="text-center"><h6>{{ $product->presentacion }}</h6></td>
                                        <td class="text-center"><h6>{{ $product->cantidad }}</h6></td>
                                        <td class="text-center"><h6>{{ number_format($product->existencia, 2) }}</h6></td>
                                        <td class="text-center">
                                            <button wire:click.prevent="Add({{ $product->id }})"
                                                class="btn btn-primary btn-sm add-product"
                                                @if ($product->existencia == 0) disabled @endif>
                                                <i class="fas fa-cart-arrow-down mr-1"></i> Agregar
                                            </button>
                                        </td>
                                    </tr>
                                @empty
                                    <tr><td colspan="6" class="text-center">SIN RESULTADOS</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            {{-- Tabla de existencias por sucursal --}}
            {{--  -@if (count($detalleExistencias) > 0)
        <div class="table-responsive mt-2">
            <table class="table table-sm table-bordered text-center">
                <thead>
                    <tr>
                        <th>Sucursal</th>
                        <th>Existencia</th>
                        <th>Ventas 30 días</th>
                        <th>Ventas 90 días</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($sucursales as $sucursal)
                        @php
                            $d = $detalleExistencias[$sucursal->id] ?? ['existencia'=>0,'ventas30'=>0,'ventas90'=>0,'color'=>'#f0f0f0'];
                        @endphp
                        <tr style="background: {{ $d['color'] }}">
                            <td>{{ $sucursal->numero }}</td>
                            <td>{{ number_format($d['existencia'], 2) }}</td>
                            <td>{{ $d['ventas30'] }}</td>
                            <td>{{ $d['ventas90'] }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif--}}
    @if (count($detalleExistencias) > 0)
    <div class="table-responsive mt-2">
        <table class="table table-bordered table-sm text-center mb-0" style="font-size: 11px;">
            <thead class="table-light">
                <tr style="font-size: 10px;">
                    <th style="padding: 2px;">&nbsp;</th>
                    @foreach ($sucursales2 as $sucursal)
                        <th style="padding: 2px;">Suc {{ $sucursal->numero }}</th>
                    @endforeach
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="padding: 3px;"><b>E</b></td>
                    @foreach($sucursales2 as $sucursal)
                        @php $d = $detalleExistencias[$sucursal->id] ?? ['existencia'=>0, 'color'=>'#f0f0f0']; @endphp
                        <td style="padding: 3px; background: {{ $d['color'] }}">
                            {{ number_format($d['existencia'], 2) }}
                        </td>
                    @endforeach
                </tr>
                <tr>
                    <td style="padding: 3px;"><b>V30</b></td>
                    @foreach($sucursales2 as $sucursal)
                        @php $d = $detalleExistencias[$sucursal->id] ?? ['ventas30'=>0]; @endphp
                        <td style="padding: 3px;">{{ $d['ventas30'] }}</td>
                    @endforeach
                </tr>
                <tr>
                    <td style="padding: 3px;"><b>V90</b></td>
                    @foreach($sucursales2 as $sucursal)
                        @php $d = $detalleExistencias[$sucursal->id] ?? ['ventas90'=>0]; @endphp
                        <td style="padding: 3px;">{{ $d['ventas90'] }}</td>
                    @endforeach
                </tr>
            </tbody>
        </table>
    </div>
@endif


            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<style>
    #modalSearchProduct.hide-cursor {
        cursor: none !important;
        /* Ocultar el cursor en todo el modal */
    }

    #modalSearchProduct.hide-cursor * {
        cursor: none !important;
        /* Asegurar que todos los elementos dentro del modal no muestren el cursor */
    }

    #modalSearchProduct.hide-cursor .table-responsive {
        pointer-events: none !important;
        /* Desactiva interacciones en áreas con scroll */
    }
</style>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const modal = document.getElementById('modalSearchProduct');
        let searchInput = modal.querySelector('#modal-search-input');

        // Función para actualizar la lista de productos dinámicamente
        function updateProductRows() {
            return modal.querySelectorAll('tbody tr[data-product-id]');
        }

        function focusRow(index, productRows) {
            if (index >= 0 && index < productRows.length) {
                // Eliminar estilo de focus de todas las filas
                productRows.forEach(row => {
                    row.style.outline = '';
                    row.style.backgroundColor = '';
                });

                const row = productRows[index];
                row.focus({
                    preventScroll: true
                });

                // Aplicamos el estilo al row enfocado
                row.style.outline = '2px solid #969cff';
                row.style.backgroundColor = '#e7e7ff';

                const container = modal.querySelector('.table-responsive'); // Usamos .table-responsive
                if (container) {
                    const rowRect = row.getBoundingClientRect();
                    const containerRect = container.getBoundingClientRect();

                    // Activar scroll suave
                    container.style.scrollBehavior = 'smooth';

                    // Si la fila está por debajo del área visible
                    if (rowRect.bottom > containerRect.bottom) {
                        const scrollAmount = rowRect.bottom - containerRect.bottom;
                        container.scrollTop += scrollAmount;
                    }

                    // Si la fila está por encima del área visible
                    else if (rowRect.top < containerRect.top) {
                        const scrollAmount = containerRect.top - rowRect.top;
                        container.scrollTop -= scrollAmount;
                    }
                }
            }
        }

        // Re-aplicar el estilo de focus después de la actualización de Livewire
        document.addEventListener('livewire:update', function() {
            const focusedRow = document.activeElement;
            if (focusedRow && focusedRow.tagName === 'TR' && focusedRow.hasAttribute(
                'data-product-id')) {
                focusedRow.style.outline = '2px solid #969cff';
                focusedRow.style.backgroundColor = '#e7e7ff';
            }
        });


        modal.addEventListener('keydown', function(event) {
            let productRows = updateProductRows();
            const focusedElement = document.activeElement;
            let index = Array.from(productRows).indexOf(focusedElement);
            let cursorTimeout;
            if (event.key === 'ArrowDown') {
                event.preventDefault();
                if (index === -1) {
                    focusRow(0, productRows);
                    emitExistencias(productRows[0]); // Emitir al enfocar la primera fila
                } else if (index < productRows.length - 1) {
                    focusRow(index + 1, productRows);
                    emitExistencias(productRows[index + 1]);
                }
            } else if (event.key === 'ArrowUp') {
                event.preventDefault();
                if (index > 0) {
                    focusRow(index - 1, productRows);
                    emitExistencias(productRows[index - 1]);
                } else if (index === 0) {
                    searchInput.focus();
                }
            } else if (event.key === 'Enter' && index !== -1) {
                event.preventDefault();
                const addButton = productRows[index].querySelector('button.btn-primary');
                if (addButton) {
                    addButton.click();
                    $('#modalSearchProduct').modal('hide');
                }
            }

        });


        // // // Al abrir el modal
        // $('#modalSearchProduct').on('shown.bs.modal', function () {
        //     document.getElementById('modalSearchProduct').classList.add('hide-cursor');
        // });

        // // // Al cerrar el modal
        // $('#modalSearchProduct').on('hidden.bs.modal', function () {
        //     document.getElementById('modalSearchProduct').classList.remove('hide-cursor');
        // }); 




        function emitExistencias(row) {
            if (!row) return;
            const productId = row.getAttribute('data-product-id');
            if (productId) {
                Livewire.emit('loadExistencias', productId);
            }
        }

        // // Evento para cargar existencias al pasar el mouse sobre una fila
        // modal.addEventListener('click', function(event) {
        //     const row = event.target.closest('tr[data-product-id]');
        //     if (row) {
        //         const productId = row.getAttribute('data-product-id');
        //         Livewire.emit('loadExistencias', productId);
        //     }
        // });

        // Cerrar modal al hacer clic en Agregar
        document.addEventListener('click', function(event) {
            if (event.target.closest('.add-product')) {
                $('#modalSearchProduct').modal('hide');
            }
        });

        // // Actualizar las filas después de que Livewire actualice la lista de productos
        document.addEventListener('livewire:update', function() {
            let productRows = updateProductRows();
        });

        // Foco en el campo de búsqueda al abrir el modal
        $('#modalSearchProduct').on('shown.bs.modal', function() {
            searchInput.focus();
        });
    });
</script>
