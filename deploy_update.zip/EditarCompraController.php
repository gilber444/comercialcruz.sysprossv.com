<?php

namespace App\Http\Livewire;

use App\Models\ActividadEconomica;
use App\Models\Compras;
use App\Models\ComprasDetalles;
use App\Models\CuentasPagar;
use App\Models\Departamentos;
use App\Models\Distritos;
use App\Models\Inventarios;
use App\Models\Kardex;
use App\Models\Municipios;
use App\Models\Notificacion;
use App\Models\Pagos;
use App\Models\Precios;
use App\Models\Productos;
use App\Models\Proveedores;
use App\Models\Sucursales;
use App\Models\tipoCompras;
use App\Models\TipoPersona;
use App\Models\tmpCompras;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Livewire\Component;

class EditarCompraController extends Component
{
    public $total, $itemsQuantity, $fechaV = [], $can = [], $pri = [], $uni = [], $sucursales = [];

    // para guardar la compra
    public $proveedorSelectId, $proveedorSelectName, $proveedorCompras, $factura, $correlativo, $serie, $fecha, $condiPago, $vendedor, $proveedores, $tipos, $select_id, $car, $personas, $actividades, $departamentos, $municipios, $distritos, $sucursal, $percepcion, $subtotal, $iva, $totales, $items;

    public function mount($id)
    {
        $user = Auth::user();
        $this->select_id = $id;
        $compras = Compras::find($id);
        $this->proveedores = Proveedores::select('id', 'nombre')->orderBy('nombre')->get();
        $this->proveedorSelectId = $compras->id;
        $this->proveedorSelectName = $this->proveedores->first()->name;
        $this->proveedorCompras = $compras->proveedor;
        $this->sucursales = Sucursales::all();
        $this->tipos = tipoCompras::all();
        $this->personas = TipoPersona::all();
        $this->actividades = ActividadEconomica::all();
        $this->departamentos = Departamentos::all();
        $this->municipios = Municipios::all();
        $this->distritos = Distritos::all();
        $this->car = ComprasDetalles::where('compra', $id)->join('productos as p', 'p.id', 'compras_detalles.producto')->join('medidas as m', 'm.id', 'compras_detalles.medida')->select('compras_detalles.id', 'p.nombreProducto', 'p.id as producto', 'compras_detalles.cantidad', 'compras_detalles.costo', 'compras_detalles.total', 'compras_detalles.fechaVencimiento', 'm.unidad')->get();

        $totalDetalle = ComprasDetalles::where('compra', $id)->sum('total');

        // Percepción se mantiene igual
        $this->percepcion = $compras->percepcion;

        $cantidadDetalle = ComprasDetalles::where('compra', $id)->sum('cantidad');
        $this->itemsQuantity = $cantidadDetalle;

        $this->fecha = $compras->fecha;
        $this->correlativo = $compras->correlativo;
        $this->serie = $compras->serie;
        $this->condiPago = $compras->condi_pago;
        $this->vendedor = $compras->vendedor;
        $this->factura = $compras->tipo;
        $this->select_id = $id;
        $this->proveedorCompras = $compras->proveedor;
        $this->sucursal = $compras->sucursal;


        $this->cargaData();
    }

    public function render()
    {
        return view('livewire.compras.editar-compra')
            ->extends('layouts.theme.app')
            ->section('content');
    }

    protected $listeners = [
        'deleteRow' => 'Destroy',
        'deleteRoww' => 'DestroyProd',
        'scan-code-byid' => 'ScanCodeById',
        'clearCart' => 'clearCart',
        'scan-code' => 'ScanCode'
    ];

    public function clearCart()
    {
        $user_id = Auth::user()->id;
        //tmpCompras::where('usuario', $user_id)->delete();
        $this->cargaData();
    }

    public function ScanCodeById($product)
    {
        $this->increaseQty($product);
    }

    public function ScanCode($barcode, $cant = 1)
    {
        $user = Auth::user();

        $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
            ->join('inventarios as i', 'i.producto', 'productos.id')
            ->where('p.codebar', 'like', '%' . $barcode . '%')
            ->where('i.sucursal', $user->sucursal)
            ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'p.cantidad', 'i.sucursal', 'p.id as precio')
            ->first();

        $this->increaseQty($product->precio);
    }

    public function increaseQty($id, $cant = 1)
    {

        $user = Auth::user();

        $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
            ->join('inventarios as i', 'i.producto', 'productos.id')
            ->where('p.id', $id)
            ->where('i.sucursal', $user->sucursal)
            ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'i.sucursal', 'p.id as idpre', 'p.costociva', 'p.medida as uni')
            ->first();

        if ($product) {

            if ($this->factura == 1) {
                $costo = $product->costosiva;
            } else {
                $costo = $product->costociva;
            }

            $detalles = ComprasDetalles::create([
                'compra' => $this->select_id,
                'producto' => $product->id,
                'medida' => $product->uni,
                'cantidad' => $cant,
                'ingreso' => $cant,
                'costo' => $costo,
                'total' =>$cant * $costo,
                'fechaVencimiento' => null,
            ]);
        } else {
            $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
                ->join('inventarios as i', 'i.producto', 'productos.id')
                ->where('p.id', $id)
                //->where('i.sucursal', $user->sucursal)
                ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'i.sucursal', 'p.id as idpre', 'p.costociva')
                ->first();
            //$p = Precios::find($id);
            $insert = Inventarios::firstOrCreate(
                [
                    'producto' => $product->id,
                    'sucursal' => $user->sucursal,
                ],
                [
                    'empresa' => $user->empresa,
                    'existencia' => 0
                ]
            );

            // Solo crear kardex inicial si el inventario acaba de nacer (existencia 0 y sin kardex previo)
            $tieneKardex = Kardex::where('inventario', $insert->id)->exists();
            if (!$tieneKardex) {
                Kardex::create([
                    'producto' => $product->id,
                    'inventario' => $insert->id,
                    'descripcion' => 'Nuevo producto',
                    'fecha' => date('Y-m-d'),
                    'hora' => date('H:i:s'),
                    'ingresoCantidad' => 0.00,
                    'ingresoValor' => 0.00,
                    'egresoCantidad' => 0.00,
                    'egresoValor' => 0.00,
                    'saldoCantidad' => 0.00,
                    'saldoValor' => 0.00
                ]);
            }

            $product = Productos::join('precios as p', 'productos.id', '=', 'p.producto')
                ->join('inventarios as i', 'i.producto', 'productos.id')
                ->where('p.id', $id)
                //->where('i.sucursal', $user->sucursal)
                ->select('productos.*', 'i.existencia', 'p.codebar', 'i.id as inventario', 'p.costosiva', 'i.sucursal', 'p.id as idpre', 'p.costociva')
                ->first();

            if ($this->factura == 1) {
                $costo = $product->costosiva;
            } else {
                $costo = $product->costociva;
            }

            ComprasDetalles::create([
                'compra' => $this->select_id,
                'producto' => $product->producto,
                'medida' => $product->uni,
                'cantidad' => $cant,
                'ingreso' => $cant,
                'costo' => $costo,
                'total' => $cant * $costo,
                'fechaVencimiento' => null,
            ]);
        }
        $this->cargaData();
        $this->emit('scan-ok');
    }

    public function updateQty($id)
    {
        $cantidades = round($this->can[$id], 2);
        $user_id = Auth::user()->id;

        $exist = ComprasDetalles::find($id);
        $compra = Compras::find($exist->compra);
        $cantActual = $exist->cantidad;

        $pre = Precios::where('producto', $exist->producto)
            ->where('medida', $exist->medida)
            ->first();

        // Actualizar Compra Detalle
        $exist->cantidad = $cantidades;
        $exist->total = $cantidades * $exist->costo;
        $exist->ingreso = $pre->cantidad * $cantidades;
        $exist->save();

        // Ajuste de inventario
        $inventario = Inventarios::where('producto', $exist->producto)
            ->where('sucursal', $compra->sucursal)
            ->first();

        //$diferencia = $cantidades/* 24 */ - $cantActual //cant1;

        if ($cantidades > $cantActual) {
            $ingreso = $cantidades;
            $egreso = 0;
            $nuevaExistencia = $inventario->existencia + $ingreso;
        } elseif ($cantidades < $cantActual) {
            $ingreso = 0;
            $egreso = abs($cantidades);
            $nuevaExistencia = $inventario->existencia - $egreso;
        } else {
            $ingreso = 0;
            $egreso = 0;
            $nuevaExistencia = $inventario->existencia;
        }

        $inventario->existencia = $nuevaExistencia;
        $inventario->save();

        // Registrar en Kardex
        /*Kardex::create([
            'producto' => $exist->producto,
            'inventario' => $inventario->id,
            'descripcion' => 'Actualización del producto en compra ' . $compra->correlativo,
            'fecha' => date('Y-m-d'),
            'hora' => date('H:i:s'),
            'ingresoCantidad' => $ingreso,
            'ingresoValor' => $ingreso * $exist->costo,
            'egresoCantidad' => $egreso,
            'egresoValor' => $egreso * $exist->costo,
            'saldoCantidad' => $nuevaExistencia,
            'saldoValor' => $nuevaExistencia * $exist->costo
        ]);*/

        $this->cargaData();
    }



    public function cargaData()
    {
        $user_id = Auth::user()->id;

        $this->car = ComprasDetalles::with('RProductos.Rmedidas')->where('compra', $this->select_id)->get();
        $compra = Compras::find($this->select_id);

        $this->itemsQuantity = ComprasDetalles::where('compra', $this->select_id)->count();

        if ($this->factura == 1) {
            $s = ComprasDetalles::where('compra', $this->select_id)->sum('total');
            $this->total = $compra->total;
            $this->subtotal =  $compra->subtotal;
            $this->iva = $compra->iva;
            $this->percepcion = $compra->percepcion;
            $this->totales = $compra->total;
        } else {
            $this->subtotal =   $compra->subtotal;
            $this->iva = 0.00;
            $this->totales = $compra->total;
            $this->total = $compra->total;
        }

        if ($this->car) {
            foreach ($this->car as $r) {
                $this->fechaV[$r->id] = $r->vencimiento;
                $this->can[$r->id] = $r->cantidad;
                $this->pri[$r->id] = $r->costo;
                $this->uni[$r->id] = $r->medida;
            }
        }
        //$this->totales =  $this->total + $this->percepcion;
        //return redirect()->to(request()->header('Referer'));
        //$this->CalcularPercicionProveedor();
    }


    public function DestroyProd(ComprasDetalles $detalle)
    {
        $up = Compras::find($detalle->compra);
        $exis = Inventarios::where('producto', $detalle->producto)->where('sucursal', $up->sucursal)->first();

        $nuevo = $exis->existencia - $detalle->ingreso;

        $exis->existencia = $nuevo;
        $exis->save();
        $up = Compras::find($detalle->compra);
        $nuevoTotal = $up->total - $detalle->total;

        $nuevoSubtotal = $nuevoTotal / 1.13;
        $nuevoIVA = $nuevoTotal - $nuevoSubtotal;

        // Actualizar valores en la compra
        $up->total = $nuevoTotal;
        $up->subtotal = $nuevoSubtotal;
        $up->iva = $nuevoIVA;
        $up->save();

        /*$kar = Kardex::where('producto', $detalle->producto)->where('inventario', $exis->id)->latest('id')->first();
        $kard = Kardex::create([
            'producto' => $detalle->producto,
            'inventario' => $exis->id,
            'descripcion' => 'Eliminacion de la ' . $kar->descripcion,
            'fecha' => date('Y-m-d'),
            'hora' => date('H:i:s'),
            'ingresoCantidad' => 0.00,
            'ingresoValor' => 0.00,
            'egresoCantidad' => $detalle->ingreso,
            'egresoValor' => $detalle->total,
            'saldoCantidad' => $nuevo,
            'saldoValor' => $kar->saldoValor - $detalle->total
        ]); */

        //dd($kar);
        $detalle->delete();
        $this->emit('item-deleted', 'Producto Eliminado');
        return redirect()->to(request()->header('Referer'));
    }

    public function resetUI()
    {
        $this->factura = '';
        $this->correlativo = '';
        $this->serie = '';
        $this->fecha = '';
        $this->condiPago = '';
        $this->vendedor = '';
        $this->proveedorCompras = '';
        $this->select_id = 0;
    }

    public function Update($id)
    {
        $user_id = Auth::user()->id;
        $horaActual = date('H:i:s');

        $up = Compras::find($id);


        if ($this->factura == 1) {
            $iva = (($this->subtotal * 1.13) - $this->subtotal);
            $total = $this->subtotal + $iva + $this->percepcion;
        } else {
            $iva = 0;
            $total = $this->subtotal + $iva;
        }
        $up->tipo = $this->factura;
        $up->correlativo = $this->correlativo;
        $up->serie = $this->serie;
        $up->fecha = $this->fecha;
        $up->condi_pago = $this->condiPago;
        $up->vendedor = $this->vendedor;
        $up->proveedor = $this->proveedorCompras;
        $up->iva = $iva;
        $up->percepcion = $this->percepcion;
        $up->total = $total;

        $up->save();

            $items = ComprasDetalles::where('compra', $this->select_id)->get();

            /**Manejar Cuentas por Pagar o Pagos**/
            if ($this->condiPago === 'Credito') {
                $cuentas = CuentasPagar::where('compra', $this->select_id)->first();
                $detalles = ComprasDetalles::where('compra', $this->select_id)->sum('total');

                $cuentas->compra = $this->select_id;
                $cuentas->proveedor = $up->proveedor;
                $cuentas->monto_total = $total;
                $cuentas->saldo = $total;
                $cuentas->estado = 'pendiente';
                $cuentas->fecha_vencimiento = now()->addDays(30);

                $cuentas->save();
            }

        $this->clearCart();
        $this->emit('item-updated', 'Datos de la Compra Actualizada');
        $this->ResetUI();
        return Redirect::to('/compras');
    }

    public function updatePre($id) {
        $precio = $this->pri[$id];

        $detalle = ComprasDetalles::find($id);
        $detalle->costo = $precio;
        $detalle->total = $precio * $detalle->cantidad;
        $detalle->save();

        $compra = Compras::find($this->select_id);

        $s = ComprasDetalles::where('compra', $this->select_id)->sum('total');

        if ($this->factura == 1) {

            $subto = $s;
            $sub2 = $s * 1.13;
            $compra->subtotal = $s;
            $compra->iva = $sub2-$s;
            $compra->total = $s + $compra->iva + $compra->percepcion;
            $compra->save();
        } else {

            $compra->subtotal = $s;
            $compra->total = $s + $compra->iva + $compra->percepcion;
            $compra->save();
        }
        $this->cargaData();

    }
}
