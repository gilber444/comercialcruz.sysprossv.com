<?php

namespace App\Http\Livewire;

use App\Models\Ajustes;
use App\Models\AjustesDetalles;
use App\Models\Empresas;
use App\Models\Inventarios;
use App\Models\Kardex;
use App\Models\Productos;
use App\Models\Sucursales;
use App\Models\User;
use App\Traits\GenerarJsonAjuste;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\WithPagination;

class AjustesController extends Component
{
    use WithPagination;
    use GenerarJsonAjuste;

    public $detalleAjustes = [], $productos, $sucursales, $producto, $sucursalOrigen,
        $cantidad, $detalle, $estado, $tipo, $search, $selected_id, $pageTitle, $componentName, $UsuarioReversor;

    public $filterStatus  = '';
    public $filterTipo    = '';
    public $filterSucursal = '';
    public $fechaDesde;
    public $fechaHasta;
    public $perPage       = 20;

    public function mount()
    {
        $this->pageTitle    = 'Listado';
        $this->componentName = 'Ajustes';
        $this->UsuarioReversor = User::find(Auth::user()->id);
        $this->fechaDesde   = now()->startOfMonth()->toDateString();
        $this->fechaHasta   = now()->endOfMonth()->toDateString();
    }

    public function paginationView()
    {
        return 'vendor.livewire.bootstrap';
    }

    public function setRango(string $rango): void
    {
        match ($rango) {
            'hoy'    => [$this->fechaDesde, $this->fechaHasta] = [now()->toDateString(), now()->toDateString()],
            'semana' => [$this->fechaDesde, $this->fechaHasta] = [now()->startOfWeek()->toDateString(), now()->endOfWeek()->toDateString()],
            'mes'    => [$this->fechaDesde, $this->fechaHasta] = [now()->startOfMonth()->toDateString(), now()->endOfMonth()->toDateString()],
            'anio'   => [$this->fechaDesde, $this->fechaHasta] = [now()->startOfYear()->toDateString(), now()->endOfYear()->toDateString()],
            'todo'   => [$this->fechaDesde, $this->fechaHasta] = ['', ''],
            default  => null,
        };
        $this->resetPage();
    }

    public function limpiarFiltros(): void
    {
        $this->search        = '';
        $this->filterStatus  = '';
        $this->filterTipo    = '';
        $this->filterSucursal = '';
        $this->fechaDesde    = now()->startOfMonth()->toDateString();
        $this->fechaHasta    = now()->endOfMonth()->toDateString();
        $this->perPage       = 20;
        $this->resetPage();
    }

    public function render()
    {
        $query = Ajustes::join('sucursales as s', 's.id', 'ajustes.sucursal')
            ->select('ajustes.*', 's.nombre as sucursal_nombre')
            ->where('ajustes.sucursal', '!=', 12)
            ->orderBy('ajustes.id', 'desc');

        if ($this->fechaDesde && $this->fechaHasta) {
            $query->whereBetween('ajustes.fecha', [$this->fechaDesde, $this->fechaHasta]);
        } elseif ($this->fechaDesde) {
            $query->where('ajustes.fecha', '>=', $this->fechaDesde);
        } elseif ($this->fechaHasta) {
            $query->where('ajustes.fecha', '<=', $this->fechaHasta);
        }

        if ($this->filterStatus) {
            $query->where('ajustes.status', $this->filterStatus);
        }

        if ($this->filterTipo) {
            $query->where('ajustes.tipo', $this->filterTipo);
        }

        if ($this->filterSucursal) {
            $query->where('ajustes.sucursal', $this->filterSucursal);
        }

        if ($this->search) {
            $s = trim($this->search);
            $query->where(function ($q) use ($s) {
                $q->where('s.nombre', 'like', "%{$s}%")
                  ->orWhere('ajustes.detalle', 'like', "%{$s}%")
                  ->orWhere('ajustes.id', 'like', "%{$s}%");
            });
        }

        $totalRegistros = $query->count();
        $data           = $query->paginate($this->perPage);

        $sucursalesList = Sucursales::where('id', '!=', 12)->orderBy('nombre')->get();

        return view('livewire.ajustes.ajustes', [
            'ajustes'        => $data,
            'totalRegistros' => $totalRegistros,
            'sucursalesList' => $sucursalesList,
        ])->extends('layouts.theme.app')->section('content');
    } 

    protected $listeners = [
        'deleteRow' => 'Destroy',
        'UpdateRow' => 'Update',
        'aplicarConCredenciales' => 'aplicarConCredenciales'
    ];

    public function Update($id)
    {

        $ajuste = Ajustes::where('id', $id)->latest()->first();

        $ajuste->update([
            'status' => 'Realizado'
        ]);

        $this->emit('item-updated', 'Ajuste Actualizado');
    }

    public function Destroy($id)
    {
        $ajuste = Ajustes::where('id', $id)->latest()->first();

        $ajuste->update([
            'status' => 'Eliminado'
        ]);

        $ajuste->delete();

        $this->emit('item-deleted', 'Ajuste Eliminado');
    }

    public function DestroyP($detalleId)
    {
        // [2026-03-24] Solo elimina el detalle — el ajuste no está Finalizado, no hay kardex que revertir
        $detalle = AjustesDetalles::where('id', $detalleId)->get();
        foreach ($detalle as $det) {
            $det->delete();
        }
        $this->emit('item-deleted', 'Productos eliminados');
    }

    public function anular(Ajustes $ajuste)
    {
        // [2026-03-24] Si ya está Finalizado no se puede anular — el kardex ya fue aplicado
        if ($ajuste->status === 'Finalizado') {
            $this->emit('noti', 'No permitido', 'El ajuste ya está Finalizado y no puede anularse.', 'error');
            return;
        }

        // Solo cambiar estado — nunca tocar inventario ni kardex aquí
        $ajuste->update(['status' => 'Anulado']);

        $this->emit('item-updated', 'Ajuste Anulado');
    }

    public function cargarDetallesAjustes($ajusteId)
    {
        $this->detalleAjustes = AjustesDetalles::join('productos as p', 'p.id', 'ajustes_detalles.producto')
            ->join('medidas as m', 'm.id', 'ajustes_detalles.medida')
            ->join('ajustes', 'ajustes.id', 'ajustes_detalles.ajuste')
            ->select(
                'ajustes_detalles.id',
                'ajustes_detalles.cantidad',
                'ajustes_detalles.total',
                'p.nombreProducto as producto',
                'm.unidad as medida',
                'ajustes.status as status_ajustes'
            )
            ->where('ajustes_detalles.ajuste', $ajusteId)
            ->get();

        $this->emit('ajuste-modal', 'show modal');
    }

    public function Print($id)
    {
        $this->emit('print-ticket2', $this->GenerarJsonAjuste($id));
    }

    public function vistaPrevia($id)
    {
        $user = Auth::user();
        $empresa = Empresas::find($user->empresa);
        $imagenUrl = asset('logo/' . $empresa->image);

        $ajustes = Ajustes::findOrFail($id);
        $suc = Sucursales::where('id', $ajustes->sucursal)->first();
        $sucursal = $suc->nombre;

        $ajusteDetalle = AjustesDetalles::where('ajuste', $id)
            //->orderBy('nombre', 'asc')
            ->get();
        $totalGeneral = AjustesDetalles::where('ajuste', $id)->sum('total');

        return view('pdf.pdfAjuste', compact('user', 'ajustes', 'ajusteDetalle', 'imagenUrl', 'empresa', 'sucursal', 'totalGeneral'));
    }

    public function aplicarConCredenciales($id, $usuario, $password)
    {
        if (!\Auth::attempt(['user' => $usuario, 'password' => $password])) {
            $this->dispatchBrowserEvent('swal-error', [
                'message' => 'Credenciales incorrectas'
            ]);
            return;
        }
        $this->AprobacionAjuste($id);
    }

    public function AprobacionAjuste($id)
    {
        $emitJson = null;

        \Illuminate\Support\Facades\DB::transaction(function () use ($id, &$emitJson) {
            // lockForUpdate dentro de transacción — bloquea la fila para evitar doble aplicación
            $ajuste = Ajustes::where('id', $id)->lockForUpdate()->first();
            if (!$ajuste || $ajuste->status === 'Finalizado') {
                return;
            }

            // Segunda capa: verificar si ya existe kardex con este ajuste ID
            // Cubre el caso donde autoAproba_Direct ya aplicó pero el status no se vio actualizado
            $kardexYaExiste = Kardex::where(function ($q) use ($id) {
                $q->where('descripcion', 'like', "Ingreso por Ajuste #{$id}%")
                  ->orWhere('descripcion', 'like', "Egreso por Ajuste #{$id}%");
            })->exists();
            if ($kardexYaExiste) {
                // Sanear status si quedó inconsistente
                $ajuste->status = 'Finalizado';
                $ajuste->save();
                return;
            }

            $sucursal = Sucursales::find($ajuste->sucursal);

            // Si la sucursal es local, solo finalizar — el sync se encarga del kardex e inventario
            if ($sucursal && $sucursal->modo === 'local') {
                $ajuste->status = 'Finalizado';
                $ajuste->autorizado_por = Auth::user()->id;
                $ajuste->save();
                $emitJson = $this->GenerarJsonAjuste($ajuste->id);
                return;
            }

            $ajusteDetalle = AjustesDetalles::where('ajuste', $id)->get();

            foreach ($ajusteDetalle as $item) {
                $existencia = Inventarios::where('producto', $item->producto)
                    ->where('sucursal', $ajuste->sucursal)
                    ->lockForUpdate()
                    ->first();

                if ($ajuste->tipo == 'Ingreso') {
                    $nuevaExistencia = $item->ingreso + $existencia->existencia;
                    $existencia->existencia = $nuevaExistencia;
                    $existencia->save();

                    $ultiR = Kardex::where('producto', $item->producto)
                        ->where('inventario', $existencia->id)
                        ->lockForUpdate()
                        ->latest()
                        ->first();

                    $saldoCantidad = $nuevaExistencia;
                    $saldoValor = $ultiR ? $ultiR->saldoValor + $item->total : $item->total;

                    Kardex::create([
                        'producto'        => $item->producto,
                        'inventario'      => $existencia->id,
                        'descripcion'     => 'Ingreso por Ajuste #' . $ajuste->id . ' ' . $ajuste->detalle . ', Ingresado por ' . Auth::user()->name . ' (Ingresado desde el Servidor)',
                        'fecha'           => date('Y-m-d'),
                        'hora'            => date('H:i:s'),
                        'ingresoCantidad' => $item->ingreso,
                        'ingresoValor'    => $item->total,
                        'egresoCantidad'  => 0.00,
                        'egresoValor'     => 0.00,
                        'saldoCantidad'   => $saldoCantidad,
                        'saldoValor'      => $saldoValor,
                        'user'            => Auth::user()->id,
                    ]);
                } else {
                    $nuevaExistencia = ($item->ingreso > $existencia->existencia)
                        ? 0.00
                        : $existencia->existencia - $item->ingreso;

                    $existencia->existencia = $nuevaExistencia;
                    $existencia->save();

                    $ultiR = Kardex::where('producto', $item->producto)
                        ->where('inventario', $existencia->id)
                        ->lockForUpdate()
                        ->latest()
                        ->first();

                    $saldoCantidad = $nuevaExistencia;
                    $saldoValor = $ultiR ? $ultiR->saldoValor - $item->total : 0;

                    Kardex::create([
                        'producto'        => $item->producto,
                        'inventario'      => $existencia->id,
                        'descripcion'     => 'Egreso por Ajuste #' . $ajuste->id . ' ' . $ajuste->detalle,
                        'fecha'           => date('Y-m-d'),
                        'hora'            => date('H:i:s'),
                        'ingresoCantidad' => 0.00,
                        'ingresoValor'    => 0.00,
                        'egresoCantidad'  => $item->ingreso,
                        'egresoValor'     => $item->total,
                        'saldoCantidad'   => $saldoCantidad,
                        'saldoValor'      => $saldoValor,
                        'user'            => Auth::user()->id,
                    ]);
                }
            }

            $ajuste->status = 'Finalizado';
            $ajuste->autorizado_por = Auth::user()->id;
            $ajuste->save();

            $emitJson = $this->GenerarJsonAjuste($ajuste->id);
        });

        if ($emitJson) {
            $this->emit('print-ticket2', $emitJson);
        }
    }
}
