<?php
// app/Console/Commands/ActualizarVentasMetas.php

namespace App\Console\Commands;

use App\Services\MetasService;
use Carbon\Carbon;
use Illuminate\Console\Command;

class ActualizarVentasMetas extends Command
{
    protected $signature = 'metas:actualizar-ventas
                            {--meta= : Actualizar solo una meta específica}
                            {--fecha= : Fecha de referencia (default: hoy)}
                            {--solo-estados : Solo actualizar estados sin recalcular ventas}';

    protected $description = 'Actualiza las metas con las ventas actuales';

    protected MetasService $metasService;

    public function __construct(MetasService $metasService)
    {
        parent::__construct();
        $this->metasService = $metasService;
    }

    public function handle(): int
    {
        $metaId = $this->option('meta');
        $fecha = $this->option('fecha')
            ? Carbon::parse($this->option('fecha'))
            : now();
        $soloEstados = $this->option('solo-estados');

        // Solo actualizar estados
        if ($soloEstados) {
            $this->info('🔄 Actualizando solo estados...');
            $actualizadas = $this->metasService->actualizarSoloEstados($fecha);
            $this->info("✅ {$actualizadas} estados actualizados");
            return Command::SUCCESS;
        }

        // Actualizar meta específica
        if ($metaId) {
            $this->info("🔄 Actualizando meta #{$metaId}...");
            $resultado = $this->metasService->actualizarMetaEspecifica($metaId, $fecha);

            if ($resultado) {
                $this->info("✅ Meta #{$metaId} actualizada correctamente");
            } else {
                $this->error("❌ Error actualizando meta #{$metaId}");
                return Command::FAILURE;
            }

            return Command::SUCCESS;
        }

        // Actualizar todas las metas
        $this->info('🔄 Actualizando todas las metas...');

        $bar = $this->output->createProgressBar();
        $bar->start();

        $resultado = $this->metasService->actualizarTodasLasMetas($fecha);

        $bar->finish();
        $this->newLine(2);

        // Resumen
        $this->table(
            ['Métrica', 'Cantidad'],
            [
                ['Metas procesadas', $resultado['procesadas']],
                ['Errores', $resultado['errores']],
            ]
        );

        if ($resultado['errores'] > 0) {
            $this->warn("⚠️  Revisa los logs para ver los errores");
        } else {
            $this->info('✅ Todas las metas actualizadas correctamente');
        }

        return Command::SUCCESS;
    }
}
