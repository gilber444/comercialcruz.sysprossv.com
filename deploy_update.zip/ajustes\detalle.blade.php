@if ($itemsQuantity > 0)
    <div class="row p-1">
        <div class="table-responsive text-nowrap">
            <table class="table table-hover table-sm">
                <thead>
                    <th class="text-center">CODIGO</th>
                    <th class="text-center">DESCRIPCION</th>
                    <th class="text-center">MEDIDA</th>
                    <th class="text-center">EXISTENCIA</th>
                    <th class="text-center">CANTIDAD</th>
                    <th class="text-center">EXISTENCIA AJUSTADA</th>
                    <th class="text-center">TOTAL</th>
                </thead>
                <tbody>
                    @forelse ($cart as $item)
                        <tr>
                            <td class="text-center" width='10%'>
                                <a href="#" class="text-black" wire:click.prevent='removeItem({{ $item->id }})'><h6>{{ $item->codebar }}</h6></a>
                            </td>
                            <td>{{ $item->name }}</td>
                            <td class="text-center" width='10%'>
                                <select class="form-control" wire:model='uni.{{ $item->id }}'
                                    wire:change='updateUni({{ $item->id }})'>
                                    <option value="{{$item->unidad}}">{{$item->medida}}</option>
                                    @foreach (DB::table('precios')->join('medidas as m', 'm.id', 'precios.medida')->select('m.id','m.unidad')->where('precios.producto', $item->producto)->whereNull('precios.deleted_at')->groupBy('m.id', 'm.unidad')->get() as $medi)
                                        <option value="{{ $medi->id }}">{{ $medi->unidad }}</option>
                                    @endforeach
                                </select>
                            </td>
                            <td class="text-center" width='10%'>{{ $existenciaActual[$item->id] }}</td>
                            <td class="text-center" width='10%'>
                                <input type="text" class="form-control w-100" placeholder="{{ $item->quantity }}"
                                    id="can-{{ $item->id }}"
                                    wire:model='can.{{ $item->id }}'
                                    wire:keydown.enter="updateQty({{ $item->id }})"
                                    value="{{ $item->quantity }}">
                            </td>
                            <td class="text-center" width='10%'>{{ $existenciaAjustada[$item->id] }}</td>
                            <td class="text-center" width='10%'>{{ number_format($item->total, 2) }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center">SIN RESULTADOS</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
@else
    <div class="alert alert-primary mb-4" role="alert">
        <div class="d-flex gap-3 text-center">
            <div class="flex-shrink-0">
                <span class="badge badge-center rounded-pill bg-primary border-label-primary p-5 me-2">
                    <i class="fa-solid fa-cart-shopping fs-1"></i>
                </span>
            </div>
            <div class="flex-grow-1">
                <div class="fw-bold">Agrega productos al ajuste</div>
            </div>
        </div>
    </div>
@endif
<script>
    document.addEventListener('DOMContentLoaded', function () {
        window.livewire.on('focus-input', function (event) {
            setTimeout(() => {
                const input = document.getElementById('can-' + event.id);
                if (input) {
                    input.focus();
                    input.select();
                }
            }, 300); // espera para que el DOM esté listo
        });
    });
</script>
