@if ($itemsQuantity > 0)
    <div class="row p-1">
        <div class="table-responsive text-nowrap">
            <table class="table table-hover table-sm">
                <thead>
                    <th class="text-center">CODIGO</th>
                    <th class="text-center">DESCRIPCION</th>
                    <th class="text-center">MEDIDA</th>
                    <th class="text-right">PRECIO COMPRA</th>
                    <th class="text-center">CANTIDAD</th>
                    <!--<th class="text-center">FECHA VEN.</th>-->
                    <th class="text-center">TOTAL COMPRA</th>
                    <th class="text-center"></th>
                </thead>
                <tbody>

                    @forelse ($cart as $item)
                        <tr>
                            <td class="text-center">
                                <h6>{{ $item->codebar }}</h6>
                            </td>
                            <td>{{ $item->name }}</td>
                            <td class="text-center" width='25%'>
                                @php
                                    /*$minCant = DB::table('precios')
                                        ->where('producto', $item->producto)
                                        ->whereNull('deleted_at')
                                        ->where('escala', 'No')
                                        ->min('cantidad');

                                    $maxCant = DB::table('precios')
                                        ->where('producto', $item->producto)
                                        ->whereNull('deleted_at')
                                        ->where('escala', 'No')
                                        ->max('cantidad');

                                    $medidas = DB::table('precios')
                                        ->where('producto', $item->producto)
                                        ->whereIn('cantidad', [$minCant, $maxCant])
                                        ->whereNull('deleted_at')
                                        ->where('escala', 'No')
                                        ->get();*/
                                    $medidas = DB::table('precios')
                                        ->where('producto', $item->producto)
                                        ->where('cantidad', 1)
                                        ->where('escala', 'No')
                                        ->whereNull('deleted_at')
                                        ->get();
                                @endphp

                                <select class="form-control form-control-lg w-100" wire:model="uni.{{ $item->id }}"
                                    wire:change="updateUni({{ $item->id }})">
                                    <option value="">Elegir</option>
                                    @foreach ($medidas as $medi)
                                        <option value="{{ $medi->medida }}">{{ $medi->presentacion }} X
                                            {{ $medi->cantidad }}</option>
                                    @endforeach
                                </select>
                            </td>
                            <td class="text-center" width='25%'>
                                <input type="text"
                                    class="form-control form-control-lg w- {{ $item->newcosto < $item->price
                                        ? 'border-success text-success'
                                        : ($item->newcosto > $item->price
                                            ? 'border-danger text-danger'
                                            : '') }}"
                                    placeholder="{{ $item->newcosto }}" wire:model='pri.{{ $item->id }}'
                                    wire:keydown.enter="updatePre({{ $item->id }})"
                                    wire:change="updatePre({{ $item->id }})" value="{{ $item->newcosto }}">
                            </td>
                            <td class="text-center" width='25%'>
                                <input type="text" class="form-control form-control-lg w-100"
                                    placeholder="{{ $item->quantity }}" id="can-{{ $item->id }}"
                                    wire:model='can.{{ $item->id }}'
                                    wire:keydown.enter="updateQty({{ $item->id }})"
                                    wire:change="updateQty({{ $item->id }})"
                                    value="{{ $item->quantity }} ">{{ $item->ingreso }}
                            </td>
                            {{-- <td class="text-center">
                        <input type="date" class="form-control w-100" placeholder="{{ $item->vencimiento }}" wire:model='fechaV.{{$item->id}}' wire:change="updateFV({{$item->id}})">
                    </td> --}}
                            <td class="text-center" width='25%'>
                                <input type="text" class="form-control form-control-lg w-100"
                                    placeholder="{{ number_format($item->total, 2) }}"
                                    wire:model='totals.{{ $item->id }}'
                                    wire:keydown.enter="updateTotal({{ $item->id }})"
                                    wire:change="updateTotal({{ $item->id }})"
                                    value="{{ number_format($item->total, 2) }}">
                            </td>
                            {{-- <td class="text-center">{{ number_format($item->total,2) }}</td> --}}
                            <td class="text-center">
                                <button wire:click.prevent='removeItem({{ $item->id }})' type="button"
                                    class="btn btn-sm btn-label-primary">
                                    <i class="fa-solid fa-minus"></i>
                                </button>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center">SIN RESULTADOS</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
@else
    <div class="alert alert-primary mb-4" role="alert">
        <div class="d-flex gap-3 text-center">
            <div class="flex-shrink-0">
                <span class="badge badge-center rounded-pill bg-primary border-label-primary p-5 me-2">
                    <i class="fa-solid fa-cart-shopping fs-1"></i>
                </span>
            </div>
            <div class="flex-grow-1">
                <div class="fw-bold">Agrega productos a la Compra</div>
            </div>
        </div>
    </div>
@endif
<script>
    document.addEventListener('DOMContentLoaded', function() {
        window.livewire.on('focus-input', function(event) {
            setTimeout(() => {
                const input = document.getElementById('can-' + event.id);
                if (input) {
                    input.focus();
                    input.select();
                }
            }, 300); // espera para que el DOM esté listo
        });
    });
</script>
