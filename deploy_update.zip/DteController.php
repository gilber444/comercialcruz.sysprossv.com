<?php

namespace App\Http\Livewire;

use App\Models\dte;
use App\Models\RecepcionDte;
use App\Models\Sucursales;
use App\Traits\enviarCorreoDTE;
use App\Traits\Firmador2;
use App\Traits\FirmadorLocal;
use App\Traits\GeneraJsonC;
use App\Traits\GeneraJsonNota;
use App\Traits\RecepcionDTEC;
use App\Traits\RecepcionDTEF;
use App\Traits\RecepcionDTENota;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Livewire\Component;
use Livewire\WithPagination;

class DteController extends Component
{
    use WithPagination;
    use RecepcionDTEC;
    use RecepcionDTEF;
    use RecepcionDTENota;
    use enviarCorreoDTE;
    use GeneraJsonC;
    use GeneraJsonNota;
    use Firmador2;
    use FirmadorLocal;

    public $search, $selected_id, $pageTitle, $componentName, $jsons;

    // [2026-03-17] Filtros avanzados: estado, tipo, rango de fechas, paginación configurable
    public $filterEstado    = '';
    public $filterTipo      = '';
    public $filterSucursal  = 0;
    public $fechaDesde;
    public $fechaHasta;
    public $perPage         = 20;
    public $canViewAll      = false;

    private $pagination   = 20;

    public function mount()
    {
        $this->pageTitle    = 'Listado';
        $this->componentName = 'DTE Generados';
        $this->fechaDesde = now()->toDateString();
        $this->fechaHasta = now()->toDateString();

        $user = Auth::user();
        $this->canViewAll = $user->profile === 'Super'
            || $user->profile === 'Administrador'
            || $user->can('DTE_ViewAll');

        $this->filterSucursal = $this->canViewAll ? 0 : (int) ($user->sucursal ?? 0);
    }

    // [2026-03-17] Resetear paginación al cambiar cualquier filtro
    public function updatingSearch()         { $this->resetPage(); }
    public function updatingFilterEstado()  { $this->resetPage(); }
    public function updatingFilterTipo()    { $this->resetPage(); }
    public function updatingFilterSucursal(){ $this->resetPage(); }
    public function updatingFechaDesde()    { $this->resetPage(); }
    public function updatingFechaHasta()    { $this->resetPage(); }
    public function updatingPerPage()       { $this->resetPage(); }

    // [2026-03-17] Limpiar todos los filtros y volver al mes actual
    public function limpiarFiltros()
    {
        $this->search         = '';
        $this->filterEstado   = '';
        $this->filterTipo     = '';
        $this->filterSucursal = $this->canViewAll ? 0 : (int) (Auth::user()->sucursal ?? 0);
        $this->fechaDesde     = now()->startOfMonth()->toDateString();
        $this->fechaHasta     = now()->endOfMonth()->toDateString();
        $this->perPage        = 20;
        $this->resetPage();
    }

    // [2026-03-17] Rangos rápidos de fecha
    public function setRango(string $rango)
    {
        switch ($rango) {
            case 'hoy':
                $this->fechaDesde = now()->toDateString();
                $this->fechaHasta = now()->toDateString();
                break;
            case 'semana':
                $this->fechaDesde = now()->startOfWeek()->toDateString();
                $this->fechaHasta = now()->endOfWeek()->toDateString();
                break;
            case 'mes':
                $this->fechaDesde = now()->startOfMonth()->toDateString();
                $this->fechaHasta = now()->endOfMonth()->toDateString();
                break;
            case 'anio':
                $this->fechaDesde = now()->startOfYear()->toDateString();
                $this->fechaHasta = now()->endOfYear()->toDateString();
                break;
            case 'todo':
                $this->fechaDesde = '';
                $this->fechaHasta = '';
                break;
        }
        $this->resetPage();
    }

    public function paginationView()
    {
        return 'vendor.livewire.bootstrap';
    }

    public function render()
    {
        $user = Auth::user();

        // [2026-03-17] Query optimizada: JOIN en lugar de N+1 por fila en la vista
        $query = Dte::query()
            ->join('ventas as v', 'v.id', '=', 'dtes.venta')
            ->join('clientes as c', 'c.id', '=', 'v.cliente')
            ->join('tipo_documentos as td', 'td.id', '=', 'dtes.tipoDte')
            ->leftJoin('resumen_dtes as r', 'r.dte', '=', 'dtes.id')
            ->select(
                'dtes.id',
                'dtes.numeroControl',
                'dtes.codigoGeneracion',
                'dtes.fecEmi',
                'dtes.estado',
                'td.valor as tipo',
                'c.nombreCliente',
                DB::raw('COALESCE(r.totalPagar, 0) as totalPagar')
            )
            ->where('dtes.empresa', $user->empresa)
            ->where('dtes.estado', '<>', 'ELIMINADO');

        // [2026-03-17] Filtro por rango de fechas (aplicar solo si hay fechas definidas)
        if ($this->fechaDesde && $this->fechaHasta) {
            $query->whereBetween('dtes.fecEmi', [$this->fechaDesde, $this->fechaHasta]);
        } elseif ($this->fechaDesde) {
            $query->where('dtes.fecEmi', '>=', $this->fechaDesde);
        } elseif ($this->fechaHasta) {
            $query->where('dtes.fecEmi', '<=', $this->fechaHasta);
        }

        // [2026-03-17] Filtro por estado
        if ($this->filterEstado) {
            $query->where('dtes.estado', $this->filterEstado);
        }

        // [2026-03-17] Filtro por tipo de DTE
        if ($this->filterTipo) {
            $query->where('td.valor', $this->filterTipo);
        }

        // Filtro por sucursal
        if (!$this->canViewAll && $this->filterSucursal) {
            $query->where('dtes.sucursal', $this->filterSucursal);
        } elseif ($this->canViewAll && $this->filterSucursal > 0) {
            $query->where('dtes.sucursal', $this->filterSucursal);
        }

        // [2026-03-17] Búsqueda por número de control, código generación o cliente
        if ($this->search) {
            $s = trim($this->search);
            $query->where(function ($q) use ($s) {
                $q->where('dtes.numeroControl',    'like', "%{$s}%")
                  ->orWhere('dtes.codigoGeneracion', 'like', "%{$s}%")
                  ->orWhere('c.nombreCliente',        'like', "%{$s}%");
            });
        }

        // [2026-03-17] Listas para los filtros desplegables
        $tiposDte = DB::table('tipo_documentos')
            ->where('status', 'Activo')
            ->orderBy('valor')
            ->pluck('valor');

        $estados = collect(['PROCESADO', 'RECHAZADO', 'Creado', 'Firmado', 'ANULADO']);

        $sucursales = $this->canViewAll
            ? Sucursales::orderBy('nombre')->get(['id', 'nombre'])
            : collect();

        // [2026-03-17] Count separado para mostrar total de resultados
        $totalRegistros = $query->count();

        $dtes = $query->orderByDesc('dtes.id')->paginate($this->perPage);

        return view('livewire.dtes.dte', compact('dtes', 'tiposDte', 'estados', 'totalRegistros', 'sucursales'))
            ->extends('layouts.theme.app')
            ->section('content');
    }

    public function FirmarDTE($id)
    {
        $dte = dte::find($id);
        //$dtes = dte::where('estado', 'Creado')
        //->where('sucursal', 8)  // Corregido "suursal" por "sucursal"
        //->orderBy('id', 'asc')
        //->get();

        //foreach($dtes as $dte)
        //{
        if ($dte->tipoDte == 1) {
            $json = $this->GeneraJsonF($dte->id);
            $firma = $this->FirmadorLocal($dte->id, $json);
            $this->RecepcionDTEF($dte->id);
        } else if ($dte->tipoDte == 2) {
            $json = $this->GeneraJsonC($id);
            //$firma = $this->FirmadorDTE($id, $json);
            $firma = $this->FirmadorLocal($id, $json);
            $this->RecepcionDTEC($id);
        } else if ($dte->tipoDte == 4) {
            $json = $this->GeneraJsonNota($id);
            //$firma = $this->FirmadorDTE($id, $json);
            $firma = $this->FirmadorLocal($id, $json);
            $this->RecepcionDTENota($id);
        }
        //}
        $this->emit('item-added', 'DTE Firmado y Procesado');
    }

    public function enviarCorreo($id)
    {
        //dd($id);
        $correo = $this->enviarCorreoDTE($id);

        $this->emit('item-added', $correo);
    }

    public function GenerarDTE($id)
    {

        $dte = dte::find($id);
        /*$dtes = dte::where('estado', 'RECHAZADO')
        ->where('sucursal', 8)  // Corregido "suursal" por "sucursal"
        ->orderBy('id', 'asc')
        ->get();

        foreach($dtes as $dte)
        {*/
        if ($dte->tipoDte == 1) {
            $json = $this->GeneraJsonF($id);
            //$firma = $this->FirmadorDTE($id, $json);
            $firma = $this->FirmadorLocal($id, $json);
            $this->RecepcionDTEF($id);
        } else if ($dte->tipoDte == 2) {
            $json = $this->GeneraJsonC($id);
            //$firma = $this->FirmadorDTE($id, $json);
            $firma = $this->FirmadorLocal($id, $json);
            $this->RecepcionDTEC($id);
        } else if ($dte->tipoDte == 4) {
            $json = $this->GeneraJsonNota($id);
            //$firma = $this->FirmadorDTE($id, $json);
            $firma = $this->FirmadorLocal($id, $json);
            $this->RecepcionDTENota($id);
        } else if ($dte->tipoDte == 10) {
            $json = $this->GeneraJsonS($id);
            //$firma = $this->FirmadorDTE($id, $json);
            $firma = $this->FirmadorLocal($id, $json);
            $this->RecepcionDTESujeto($id);
        }
        //}

        $this->emit('item-added', 'DTE Firmado y Procesado');
    }

    public function Detalle($id)
    {
        $re = RecepcionDte::where('dte', $id)->latest()->first();

        $this->jsons = $re->josn;
        $this->emit('sshoww-modal', 'show modal');
    }

    public function show($id)
    {
        // Recupera el registro de la base de datos
        $rec = dte::findOrFail($id);
        $json = $this->inflateJson($rec->jsonDte);
        //$json = $record->jsonDte; // Asegúrate de usar el campo correcto

        if ($json === null) {
            abort(415, 'No se pudo descomprimir jsonDte.');
        }

        $json = $this->prettyJson($json);
        $fname = $this->fileName($rec->codigoGeneracion ?? 'dte');

        // Devuelve el JSON como respuesta
        return response($json, 200)
            ->header('Content-Type', 'application/json')
            ->header('Content-Disposition', 'inline; filename="' . $fname . '.json"');
    }

    public function download($id)
    {
        $rec  = Dte::findOrFail($id);
        // 🔹 OJO: usar el mismo campo jsonDte (no json_field)
        $json = $this->inflateJson($rec->jsonDte);

        if ($json === null) {
            abort(415, 'No se pudo descomprimir jsonDte.');
        }

        $json = $this->prettyJson($json);
        $fname = $this->fileName($rec->codigoGeneracion ?? 'dte');

        return response($json, 200)
            ->header('Content-Type', 'application/json; charset=utf-8')
            ->header('Content-Disposition', 'attachment; filename="' . $fname . '.json"');
    }

    public function confirmProcessing($id)
    {
        // Emitir el evento para mostrar la alerta de procesamiento
        $this->emit('processingDTE');

        // Llamar a la función GenerarDTE
        $this->GenerarDTE($id);
    }

    protected $listeners = [
        'GenerarDTE' => 'GenerarDTE',
    ];

    private function inflateJson(?string $bin): ?string
    {
        if ($bin === null) return null;

        // 1) Intento normal (gzcompress de PHP)
        $out = @gzuncompress($bin);
        if ($out !== false) return $out;

        // 2) Intento COMPRESS() de MySQL (zlib con cabecera de 4 bytes)
        $out = @gzuncompress(substr($bin, 4));
        if ($out !== false) return $out;

        // 3) Por si tienes filas antiguas sin comprimir (texto plano JSON)
        $trim = ltrim($bin);
        if ($trim !== '' && ($trim[0] === '{' || $trim[0] === '[')) {
            return $bin;
        }

        return null;
    }

    private function prettyJson(string $json): string
    {
        $data = json_decode($json, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return $json; // Devuelve tal cual si no es JSON válido
        }
        return json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    }

    /** Limpia nombre de archivo. */
    private function fileName(string $base): string
    {
        $name = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $base);
        return $name !== '' ? $name : 'dte_' . now()->format('Ymd_His');
    }
}
