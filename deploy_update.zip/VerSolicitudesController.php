<?php

namespace App\Http\Livewire;

use App\Models\Inventarios;
use App\Models\Kardex;
use App\Models\Solicitudes;
use App\Models\SolicitudesDetalles;
use App\Models\Sucursales;
use App\Models\User;
use DB;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\WithPagination;

class VerSolicitudesController extends Component
{
    use WithPagination;

    public $search,
        $selected_id,
        $pageTitle,
        $componentName,
        $sucursalSeleccionada,
        $ubicacion,
        $numero,
        $fecha,
        $origenes,
        $destinos,
        $solicitud,
        $detalle,
        $desde,
        $selectedDestination = [],
        $sid,
        $snombre,
        $cantidad = [],
        $estados,
        $estado,
        $accion,
        $detalleSolicitud = [],
        $totalSolicitud = 0,
        $UsuarioReversor;

    public $filterEstado    = '';
    public $filterOrigen    = '';
    public $filterDestino   = '';
    public $fechaDesde;
    public $fechaHasta;
    public $perPage         = 20;

    public function mount()
    {
        $this->pageTitle     = 'Listado';
        $this->componentName = 'Solicitudes Realizadas';
        $this->UsuarioReversor = User::find(Auth::user()->id);
        $this->fechaDesde    = now()->startOfMonth()->toDateString();
        $this->fechaHasta    = now()->endOfMonth()->toDateString();
    }

    public function setRango(string $rango): void
    {
        match ($rango) {
            'hoy'    => [$this->fechaDesde, $this->fechaHasta] = [now()->toDateString(), now()->toDateString()],
            'semana' => [$this->fechaDesde, $this->fechaHasta] = [now()->startOfWeek()->toDateString(), now()->endOfWeek()->toDateString()],
            'mes'    => [$this->fechaDesde, $this->fechaHasta] = [now()->startOfMonth()->toDateString(), now()->endOfMonth()->toDateString()],
            'anio'   => [$this->fechaDesde, $this->fechaHasta] = [now()->startOfYear()->toDateString(), now()->endOfYear()->toDateString()],
            'todo'   => [$this->fechaDesde, $this->fechaHasta] = ['', ''],
            default  => null,
        };
        $this->resetPage();
    }

    public function limpiarFiltros(): void
    {
        $this->search       = '';
        $this->filterEstado = '';
        $this->filterOrigen = '';
        $this->filterDestino = '';
        $this->fechaDesde   = now()->startOfMonth()->toDateString();
        $this->fechaHasta   = now()->endOfMonth()->toDateString();
        $this->perPage      = 20;
        $this->resetPage();
    }

    public function cargaDetalle()
    {
        $this->detalle = SolicitudesDetalles::join('productos as p', 'p.id', 'solicitudes_detalles.producto')
            ->select('solicitudes_detalles.*', 'p.codebar3', 'p.nombreProducto')
            ->where('estado', 'Despachado')
            ->where('solicitud', $this->selected_id)

            ->get();
    }

    public function paginationView()
    {
        return 'vendor.livewire.bootstrap';
    }

    public function render()
    {
        $user = Auth::user();

        $query = Solicitudes::with('Rorigen', 'Rdestino', 'Rsolicitante')
            ->whereNull('solicitudes.deleted_at')
            ->where('origen', '!=', 12)
            ->where('destino', '!=', 12)
            ->orderBy('solicitudes.id', 'desc');

        if (!in_array($user->profile, ['Administrador', 'Super', 'Auditor', 'Gerente General', 'Compras'])) {
            $query->where('solicitudes.destino', $user->sucursal);
        }

        if ($this->fechaDesde && $this->fechaHasta) {
            $query->whereBetween(DB::raw('DATE(solicitudes.fecha)'), [$this->fechaDesde, $this->fechaHasta]);
        } elseif ($this->fechaDesde) {
            $query->where(DB::raw('DATE(solicitudes.fecha)'), '>=', $this->fechaDesde);
        } elseif ($this->fechaHasta) {
            $query->where(DB::raw('DATE(solicitudes.fecha)'), '<=', $this->fechaHasta);
        }

        if ($this->filterEstado) {
            $query->where('solicitudes.estado', $this->filterEstado);
        }

        if ($this->filterOrigen) {
            $query->where('solicitudes.origen', $this->filterOrigen);
        }

        if ($this->filterDestino) {
            $query->where('solicitudes.destino', $this->filterDestino);
        }

        if (!empty($this->search)) {
            $s = '%' . trim($this->search) . '%';
            $query->where(function ($q) use ($s) {
                $q->where('solicitudes.numero', 'like', $s)
                  ->orWhereHas('Rorigen', fn($q2) => $q2->where('nombre', 'like', $s))
                  ->orWhereHas('Rdestino', fn($q2) => $q2->where('nombre', 'like', $s))
                  ->orWhereHas('Rsolicitante', fn($q2) => $q2->where('name', 'like', $s));
            });
        }

        $totalRegistros = $query->count();
        $data           = $query->paginate($this->perPage);

        $sucursalesList = Sucursales::whereNotIn('id', [12])->orderBy('nombre')->get();

        return view('livewire.existencias.ver-solicitudes', [
            'data'           => $data,
            'totalRegistros' => $totalRegistros,
            'sucursalesList' => $sucursalesList,
        ])->extends('layouts.theme.app')->section('content');
    }

    protected $listeners = [
        'print-ticket' => 'printTicket',
    ];

    public function Autorizar($id)
    {
        $user = Auth::user();
        $record = Solicitudes::with('Rorigen', 'Rdestino', 'Rsolicitante')->find($id);
        $this->numero = $record->numero;
        $this->selected_id = $record->id;
        $this->fecha = $record->fecha;
        $this->origenes = $record->Rorigen->nombre;
        $this->destinos = $record->Rdestino->nombre;
        $this->solicitud = $record->Rsolicitante->name;
        $this->sid = $record->destino;
        $this->snombre = $record->Rdestino->nombre;
        $this->estados = $record->estado;
        $this->accion = 'Autorizar';

        //$this->desde = $record->destino;

        $this->detalle = SolicitudesDetalles::with(['Rproducto', 'Rorigen', 'Rdestino'])
            ->where('solicitud', $this->selected_id)
            ->get();
        foreach ($this->detalle as $det) {
            $this->selectedDestination[$det->id] = $det->destino;
            $this->cantidad[$det->id] = $det->cantidad;
        }

        $this->mount();
        $this->emit('show-modal', 'show modal');
    }

    public function Aprobar($id)
    {
        $valorSeleccionado = $this->selectedDestination[$id] ?? null;
        $cantidadSeleccionado = $this->cantidad[$id] ?? null;

        if (empty($valorSeleccionado)) {
            $this->emit('item-error', 'Seleccione una Sucursal para su aprobacion');
        } else {
            $detalle = SolicitudesDetalles::find($id);

            if (empty($cantidadSeleccionado)) {
                $cantidadMover = $detalle->cantidad;
            } else {
                $cantidadMover = $cantidadSeleccionado;
            }

            $exis = Inventarios::where('producto', $detalle->producto)
                ->where('sucursal', $valorSeleccionado)
                ->first();

            if ($cantidadMover > $exis->existencia) {
                $this->emit('no-stock', 'Existecia insuficiente en esta sucursal');
            } else {
                $user_id = Auth::user()->id;

                $detalle->update([
                    'destino' => $valorSeleccionado,
                    'cantidad' => $cantidadMover,
                    'autorizado' => $user_id,
                    'estado' => 'Autorizado',
                ]);
                //dd('aqui');
                $detalle->save();
                $this->mount();
                $this->emit('show-modal', 'show modal');
            }
        }
    }

    public function resetUI()
    {
        $this->sucursalSeleccionada = '';
        $this->search = '';
        $this->ubicacion = '';
        $this->selected_id = 0;
        $this->ubicacion = '';
        $this->numero = '';
        $this->fecha = '';
        $this->origenes = '';
        $this->destinos = '';
        $this->solicitud = '';
        $this->detalle = '';
        $this->desde = '';
        $this->selectedDestination = [];
        $this->sid = '';
        $this->snombre = '';
        $this->cantidad = [];
        $this->resetValidation();
        $this->resetPage();
    }

    public function Update()
    {
        $soli = Solicitudes::find($this->selected_id);

        $detallesAutorizados = SolicitudesDetalles::where('solicitud', $this->selected_id)
            ->where('estado', 'Solicitado')
            ->count();

        if ($detallesAutorizados > 0) {
            $this->emit('item-error', 'No se puede autorizar la solicitud porque hay productos sin autorizar.');
        } else {
            // Actualizar el estado de la solicitud principal a 'Autorizado'
            $soli->update([
                'estado' => 'Autorizado',
            ]);

            $this->resetUI();
            $this->mount();
            $this->emit('item-updated', 'Solicitud Aprobada');
        }
    }

    public function Despacho($id)
    {
        $record = Solicitudes::join('sucursales as s1', 's1.id', 'solicitudes.origen')->join('sucursales as s2', 's2.id', 'solicitudes.destino')->select('solicitudes.*', 's1.nombre as origen', 's2.nombre as destinos')->find($id);
        $this->numero = $record->numero;
        $this->selected_id = $record->id;
        $this->fecha = $record->fecha;
        $this->origenes = $record->origen;
        $this->destinos = $record->destinos;
        $this->solicitud = $record->solicitud;
        $this->sid = $record->destino;
        $this->snombre = $record->destinos;
        $this->estado = $record->estado;
        $this->accion = 'Despachar Productos';
        //$this->desde = $record->destino;

        $this->detalle = SolicitudesDetalles::join('productos as p', 'p.id', 'solicitudes_detalles.producto')
            ->select('solicitudes_detalles.*', 'p.codebar3', 'p.nombreProducto')
            ->where('solicitud', $this->selected_id)
            ->get();
        $this->mount();
        $this->emit('show-modal', 'show modal');
    }

    public function Despachar($id)
    {
        $detalle = SolicitudesDetalles::find($id);
        $user_id = Auth::user()->id;
        $fecha = date('Y-m-d');
        $hora = date('H:i:s');

        $inven = Inventarios::where('sucursal', $detalle->destino)->where('producto', $detalle->producto)->first();

        $newExis = $inven->existencia - $detalle->cantidad;
        try {

            $detalle->despachado = $user_id;
            $detalle->estado  = 'Despachado';
            $detalle->save();

            $inven->existencia = $newExis;
            $inven->save();

            $kardex = Kardex::where('producto', $detalle->producto)->where('inventario', $inven->id)
                ->orderBy('id', 'desc')
                ->first();

            $saldoCantidad = $kardex->saldoCantidad - $detalle->cantidad;
            $saldoValor = $saldoCantidad * $detalle->costo;

            $kar = Kardex::create([
                'producto' => $detalle->producto,
                'inventario' => $inven->id,
                'descripcion' => 'Despacho de producto de la sucursal con id ' . $this->selected_id,
                'fecha' => $fecha,
                'hora' => $hora,
                'ingresoCantidad' => 0,
                'ingresoValor' => 0,
                'egresoCantidad' => $detalle->cantidad,
                'egresoValor' => $detalle->total,
                'saldoCantidad' => $saldoCantidad,
                'saldoValor' => $saldoValor,
            ]);
            $this->emit('item-confirmar', 'Producto despachado');
            $this->mount();
        } catch (\Exception $e) {
            // Manejar la excepción
            // Puedes imprimir el mensaje de error o guardar en un registro de logs
            $this->emit('item-error', 'Error al despachar producto: ' . $e->getMessage());
        }
    }

    public function DespacharTodos($id)
    {
        $user_id = Auth::user()->id;
        $soli = Solicitudes::find($id);
        $fecha = date('Y-m-d');
        $hora = date('H:i:s');

        $detallesPendientes = SolicitudesDetalles::where('solicitud', $id)->where('estado', 'Autorizado')->get();

        $soli->estado = 'Despachado';
        $soli->save();

        foreach ($detallesPendientes as $detalle) {
            try {
                $inven = Inventarios::where('sucursal', $detalle->destino)
                    ->where('producto', $detalle->producto)
                    ->first();

                if ($inven) {
                    $newExis = $inven->existencia - $detalle->cantidad;

                    $detalle->despachado = $user_id;
                    $detalle->estado = 'Despachado';
                    $detalle->save();

                    $inven->existencia = $newExis;
                    $inven->save();

                    $kardex = Kardex::where('producto', $detalle->producto)->where('inventario', $inven->id)
                        ->orderBy('id', 'desc')
                        ->first();

                    if ($kardex) {
                        $saldoCantidad = $kardex->saldoCantidad - $detalle->cantidad;
                        $saldoValor = $saldoCantidad * $detalle->costo;

                        $kar = Kardex::create([
                            'producto' => $detalle->producto,
                            'inventario' => $inven->id,
                            'descripcion' => 'Despacho de producto de la sucursal con id ' . $this->selected_id,
                            'fecha' => $fecha,
                            'hora' => $hora,
                            'ingresoCantidad' => 0,
                            'ingresoValor' => 0,
                            'egresoCantidad' => $detalle->cantidad,
                            'egresoValor' => $detalle->total,
                            'saldoCantidad' => $saldoCantidad,
                            'saldoValor' => $saldoValor,
                        ]);
                    } else {
                        // Manejar el caso donde no se encuentra un registro en Kardex
                    }
                } else {
                    // Manejar el caso donde no se encuentra un registro en Inventario
                }
            } catch (Exception $e) {
                // Manejar la excepción
                $this->emit('item-error', 'Error al despachar detalle: ' . $e->getMessage());
            }
        }

        $this->emit('item-updated', 'Productos despachados');
        $this->mount();
    }

    public function Ingreso($id)
    {
        //dd($id);
        $record = Solicitudes::join('sucursales as s1', 's1.id', 'solicitudes.origen')->join('sucursales as s2', 's2.id', 'solicitudes.destino')->select('solicitudes.*', 's1.nombre as origen', 's2.nombre as destinos')->find($id);
        $this->numero = $record->numero;
        $this->selected_id = $record->id;
        $this->fecha = $record->fecha;
        $this->origenes = $record->origen;
        $this->destinos = $record->destinos;
        $this->solicitud = $record->solicitud;
        $this->sid = $record->destino;
        $this->snombre = $record->destinos;
        $this->estado = $record->estado;
        $this->accion = 'Ingresar Productos de la ';

        $this->detalle = SolicitudesDetalles::join('productos as p', 'p.id', 'solicitudes_detalles.producto')
            ->select('solicitudes_detalles.*', 'p.codebar3', 'p.nombreProducto')
            ->where('solicitud', $this->selected_id)
            ->get();
        $this->cargaDetalle();
        $this->emit('show-modal', 'show modal');
    }

    public function Ingresar($id)
    {
        $user = Auth::user();
        $detalle = SolicitudesDetalles::find($id);

        // Bloqueo modo híbrido: no se puede ingresar a una sucursal local desde el VPS
        if (\App\Helpers\SistemaHelper::operacionBloqueada((int) $detalle->destino)) {
            $this->emit('item-confirmar', 'Bloqueado: La sucursal destino opera en modo local. Ingresa el producto desde la PC local.');
            return;
        }

        $user_id = Auth::user()->id;
        $fecha = date('Y-m-d');
        $hora = date('H:i:s');

        //dd($detalle->destino);
        $inven = Inventarios::firstOrCreate(
            [
                'empresa' => 1,
                'sucursal' => $detalle->destino,
                'producto' => $detalle->producto,
            ],
            [
                'existencia' => 0, // si no existe lo crea con 0
            ]
        );

        $newExis = $inven->existencia + $detalle->cantidad;

        $detalle->despachado = $user_id;
        $detalle->estado = 'Finalizado';
        $detalle->save();

        $inven->existencia = $newExis;
        $inven->save();

        $kardex = Kardex::where('producto', $detalle->producto)->where('inventario', $inven->id)
            ->orderBy('id', 'desc')
            ->first();

        $sucur = Sucursales::find($detalle->destino);
        $origen = Sucursales::find($detalle->origen);

        $saldoCantidad = $newExis;
        $saldoValor = $saldoCantidad * $detalle->costo;

        $kar = Kardex::create([
            'producto' => $detalle->producto,
            'inventario' => $inven->id,
            'descripcion' => 'Ingreso de producto a la sucursal ' . $sucur->nombre . ' desde la sucursal ' . $origen->nombre . 'Ingresado por ' . $user->name,
            'fecha' => $fecha,
            'hora' => $hora,
            'ingresoCantidad' => $detalle->cantidad,
            'ingresoValor' => $detalle->total,
            'egresoCantidad' => 0,
            'egresoValor' => 0,
            'saldoCantidad' => $saldoCantidad,
            'saldoValor' => $saldoValor,
        ]);
        $this->emit('item-confirmar', 'Producto Ingresado');
        $this->cargaDetalle();
    }

    public function Finalizar($id)
    {
        $detalle = Solicitudes::find($id);
        $detalle->estado = 'Finalizado';
        $detalle->save();

        $dets = SolicitudesDetalles::where('solicitud', $id)->where('estado', 'Despachado')->get();
        foreach ($dets as $d) {
            $this->Ingresar($d->id);
        }
        $this->emit('item-updated', 'Solicitud Finalizada y productos ingresados');
    }

    public function Imprimir($id)
    {
        $this->emit('print-ticketR', $this->getJsonBase64($id));
    }

    public function cargarDetallesSolicitud($id)
    {
        $this->detalleSolicitud = SolicitudesDetalles::join('productos as p', 'p.id', 'solicitudes_detalles.producto')
            ->join('medidas as m', 'm.id', 'p.medida')
            ->join('solicitudes', 'solicitudes.id', 'solicitudes_detalles.solicitud')
            ->select(
                'solicitudes_detalles.id',
                'solicitudes_detalles.cantidad',
                'solicitudes_detalles.costo',
                'solicitudes_detalles.total',
                'p.nombreProducto as producto',
                'p.codebar3',
                'm.unidad as medida'
            )
            ->where('solicitudes_detalles.solicitud', $id)
            ->get();

        $this->totalSolicitud = $this->detalleSolicitud->sum('total');

        $this->emit('detalle-modal', 'show modal');
    }

    public function syncConfirm()
    {
        $this->dispatchBrowserEvent('swal:sync-confirm');
    }

    // public function syncVpsLocal()
    // {
    //     try {
    //         $sucursal = (int) (Auth::user()->sucursal ?? 0);

    //         if ($sucursal <= 0) {
    //             $this->dispatchBrowserEvent('swal:sync-error', [
    //                 'title' => 'Error',
    //                 'text'  => 'El usuario no tiene sucursal asignada.'
    //             ]);
    //             return;
    //         }

    //         $lookback = 0;

    //         Artisan::call('sync:vps-local-manual', [
    //             '--sucursales' => $sucursal,
    //             '--lookback' => $lookback,
    //         ]);

    //         $out = trim(Artisan::output());

    //         $this->dispatchBrowserEvent('swal:sync-success', [
    //             'title' => 'Sync completada',
    //             'text'  => "✅ Sync ejecutada para sucursal {$sucursal}."
    //         ]);
    //     } catch (\Throwable $e) {
    //         $this->dispatchBrowserEvent('swal:sync-error', [
    //             'title' => 'Error',
    //             'text'  => $e->getMessage()
    //         ]);
    //     }
    // }

    public function syncVpsLocal()
	{
		try {
			$sucursal = (int) (Auth::user()->sucursal ?? 0);
			if ($sucursal <= 0) {
				$this->dispatchBrowserEvent('swal:sync-error', [
					'title' => 'Error',
					'text'  => 'El usuario no tiene sucursal asignada.'
				]);
				return;
			}

			$lookback  = 120;
			$inicioDt  = now();

			Artisan::call('sync:vps-local-manual', [
				'--sucursales' => $sucursal,
				'--lookback'   => $lookback,
			]);

			$out = trim(Artisan::output());

			// ─── Guardar log en storage/logs/sync/ ───────────────────────
			$carpeta   = storage_path('logs/');
			if (!is_dir($carpeta)) {
				mkdir($carpeta, 0755, true);
			}

			$nombreArchivo = $carpeta . '/sync-manual'. '.log';
			$linea = sprintf(
				"[%s] USER:%s SUC:%d LOOKBACK:%dmin\n%s\n%s\n",
				$inicioDt->format('Y-m-d H:i:s'),
				Auth::user()->name ?? Auth::id(),
				$sucursal,
				$lookback,
				$out,
				str_repeat('-', 80)
			);
			file_put_contents($nombreArchivo, $linea, FILE_APPEND | LOCK_EX);
			// ─────────────────────────────────────────────────────────────

			$this->dispatchBrowserEvent('swal:sync-success', [
				'title' => 'Sync completada',
				'text'  => "✅ Sync ejecutada para sucursal {$sucursal}."
			]);

		} catch (\Throwable $e) {

			// Log del error también
			$carpeta = storage_path('logs/sync');
			if (!is_dir($carpeta)) {
				mkdir($carpeta, 0755, true);
			}
			$nombreArchivo = $carpeta . '/sync-' . now()->format('Y-m-d') . '.log';
			$linea = sprintf(
				"[%s] ❌ ERROR USER:%s SUC:%s → %s\n%s\n",
				now()->format('Y-m-d H:i:s'),
				Auth::user()->name ?? Auth::id(),
				Auth::user()->sucursal ?? '?',
				$e->getMessage(),
				str_repeat('-', 80)
			);
			file_put_contents($nombreArchivo, $linea, FILE_APPEND | LOCK_EX);

			$this->dispatchBrowserEvent('swal:sync-error', [
				'title' => 'Error',
				'text'  => $e->getMessage()
			]);
		}
	}

    public function resetearPlazo($id)
    {
        $solicitud = Solicitudes::findOrFail($id);
        if (!$solicitud->fecha_limite) {
            return;
        }
        $solicitud->fecha_limite = $solicitud->fecha_limite->addDays(5);
        $solicitud->autorizado_por = Auth::user()->id;
        $solicitud->save();
        $this->emit('item-updated', 'Plazo reestablecido');
    }

}
