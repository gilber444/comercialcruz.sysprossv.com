<?php

// [2026-03-21] Comando para bloquear metas_dias a las 9:00 AM — llama MetasBloqueoDiarioService

namespace App\Console\Commands;

use App\Services\Metas\MetasBloqueoDiarioService;
use Carbon\Carbon;
use Illuminate\Console\Command;

class MetasBloquearDia extends Command
{
    protected $signature = 'metas:bloquear-dia
                            {--fecha= : Fecha a bloquear YYYY-MM-DD (default: hoy)}';

    protected $description = 'Bloquea los metas_dias del día indicado a las 9:00 AM y asume Presente a quienes no tengan registro';

    public function handle(): int
    {
        $fecha = $this->option('fecha')
            ? Carbon::parse($this->option('fecha'))
            : Carbon::today();

        $this->info("[metas:bloquear-dia] Bloqueando día: {$fecha->toDateString()}");

        try {
            $service   = app(MetasBloqueoDiarioService::class);
            $bloqueados = $service->bloquearDia($fecha);
            $this->info("[metas:bloquear-dia] Bloqueados: {$bloqueados} registros.");
            return self::SUCCESS;
        } catch (\Throwable $e) {
            $this->error("[metas:bloquear-dia] Error: " . $e->getMessage());
            return self::FAILURE;
        }
    }
}
