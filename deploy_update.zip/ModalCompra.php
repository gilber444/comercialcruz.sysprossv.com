<?php

namespace App\Http\Livewire;

use \DB;
use App\Models\Precios;
use App\Models\Productos;
use Livewire\Component;

class ModalCompra extends Component
{
    public $search, $products = [];

    public function liveSearch()
    {
        $search = trim($this->search ?? '');

         $this->products = Precios::withoutTrashed()            // 👈 excluye soft-deleted en Precios
        ->where('cantidad', 1)
        ->whereHas('Rproductos', function ($q) {
           $q->whereNull('productos.deleted_at')   // 👈 nuevo: evita productos eliminados
           ->where('productos.activo', 1);       // 👈 nuevo: solo productos activos
           // $q->where('activo', 1);                           // 👈 solo productos activos

        })
        ->where(function ($q) use ($search) {
            $q->orWhere('codebar', 'like', "%{$search}%")
            ->orWhereHas('Rproductos', function ($p) use ($search) {
                $p->where('nombreProducto', 'like', "%{$search}%");
            });
        })
        ->with(['Rproductos:id,nombreProducto'])
        ->select('id','producto','codebar','presentacion','cantidad','costosiva') // columnas mínimas
        ->orderByDesc('id')
        ->limit(50)                                        // 👈 limita en SQL (mejor performance)
        ->get();
        }
    public function render()
    {
        $this->liveSearch();
        return view('livewire.compras.modal-compra');
    }

    public function addAll()
    {
        if(count($this->products) > 0)
        {
           foreach($this->products as $product)
           {
            $this->emit('scan-code-byid', $product->id);
           }
        }
    }

    public function Add($id)
    {
        //dd($id);
        $this->emit('scan-code-byid', $id);
        //$this->search = '';
    }
}
